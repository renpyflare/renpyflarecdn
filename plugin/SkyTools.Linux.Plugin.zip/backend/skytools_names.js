#!/usr/bin/env node
"use strict";
const fs = require("fs");
const path = require("path");
const https = require("https");
const http = require("http");

function arg(i) { return process.argv.length > i + 2 ? String(process.argv[i + 2]) : ""; }
function ensureDir(p) { if (p) fs.mkdirSync(p, { recursive: true }); }
function writeText(p, text) { ensureDir(path.dirname(p)); fs.writeFileSync(p, String(text || ""), "utf8"); }

function uniqueAppIds() {
  const seen = {};
  const ids = [];
  for (let i = 1; i < process.argv.length - 2; i++) {
    const id = String(arg(i)).replace(/\D/g, "");
    if (id && !seen[id]) { seen[id] = true; ids.push(id); }
  }
  return ids;
}

function cleanName(value, id) {
  let name = String(value || "")
    .replace(/&amp;/gi, "&").replace(/&quot;/gi, '"').replace(/&#39;|&apos;/gi, "'")
    .replace(/&lt;/gi, "<").replace(/&gt;/gi, ">")
    .replace(/[\x00-\x1f\x7f]/g, " ").replace(/\s+/g, " ").trim();
  if (!name || /^\d+$/.test(name) || name.toLowerCase() === ("appid " + id).toLowerCase()) return "";
  return name.length > 180 ? name.substring(0, 180) : name;
}

function requestJson(url, timeoutMs) {
  return new Promise((resolve) => {
    try {
      const mod = url.startsWith("https") ? https : http;
      const req = mod.get(url, {
        headers: { "User-Agent": "SkyToolsPlugin/1.5.1-Millennium", Accept: "application/json,*/*" },
        timeout: timeoutMs || 7000
      }, (res) => {
        let data = "";
        res.on("data", (c) => { data += c; });
        res.on("end", () => {
          if (res.statusCode < 200 || res.statusCode >= 300) return resolve(null);
          try { resolve(JSON.parse(data || "{}")); } catch (_) { resolve(null); }
        });
      });
      req.on("error", () => resolve(null));
      req.on("timeout", () => { try { req.destroy(); } catch (_) {} resolve(null); });
    } catch (_) { resolve(null); }
  });
}

async function storeName(id) {
  const data = await requestJson("https://store.steampowered.com/api/appdetails?filters=basic&appids=" + id, 7000);
  if (!data || !data[id] || !data[id].success || !data[id].data) return "";
  return cleanName(data[id].data.name, id);
}

async function main() {
  const resultPath = arg(0);
  if (!resultPath) throw new Error("Caminho de resultado ausente.");
  const ids = uniqueAppIds();
  const names = {};
  for (const id of ids) {
    const name = await storeName(id);
    if (name) names[id] = name;
  }
  writeText(resultPath, JSON.stringify({ success: true, data: names, error: "" }));
}

main().catch((e) => {
  const resultPath = arg(0);
  try {
    writeText(resultPath, JSON.stringify({ success: false, error: e && e.message ? e.message : String(e) }));
  } catch (_) {}
});
