#!/usr/bin/env node
"use strict";
const fs = require("fs");
const path = require("path");

function arg(i) { return process.argv.length > i + 2 ? String(process.argv[i + 2]) : ""; }
function ensureDir(p) { if (p) fs.mkdirSync(p, { recursive: true }); }
function writeText(p, text) { ensureDir(path.dirname(p)); fs.writeFileSync(p, String(text || ""), "utf8"); }

const resultPath = arg(0);
const requestPath = arg(1);
const scriptPath = arg(2);
const appid = String(arg(3) || "");

try {
  if (!resultPath || !requestPath || !scriptPath || !appid) throw new Error("Parâmetros insuficientes.");
  if (!fs.existsSync(scriptPath)) throw new Error("Arquivo Lua do jogo não encontrado.");
  const request = JSON.parse(fs.readFileSync(requestPath, "utf8") || "{}");
  let text = fs.readFileSync(scriptPath, "utf8");
  const newline = text.indexOf("\r\n") >= 0 ? "\r\n" : "\n";
  let lines = text.split(/\r\n|\n|\r/);
  let changed = false;

  const requestedDlcs = Array.isArray(request.dlcs) ? request.dlcs : [];
  for (const dlc of requestedDlcs) {
    if (!dlc || !dlc.id) continue;
    const id = String(dlc.id);
    const wantEnabled = dlc.enabled === true;
    const activeRe = new RegExp("^(\\s*)addappid\\s*\\(\\s*" + id + "\\b", "i");
    const commentedRe = new RegExp("^(\\s*)--\\s*addappid\\s*\\(\\s*" + id + "\\b", "i");
    let found = false;
    for (let i = 0; i < lines.length; i++) {
      if (wantEnabled) {
        const m = lines[i].match(commentedRe);
        if (m) {
          let body = lines[i].slice(m[1].length + 2);
          if (/^[ \t]/.test(body)) body = body.slice(1);
          lines[i] = m[1] + body;
          changed = true;
          found = true;
        } else if (activeRe.test(lines[i])) found = true;
      } else {
        const m = lines[i].match(activeRe);
        if (m) {
          lines[i] = m[1] + "-- " + lines[i].slice(m[1].length);
          changed = true;
          found = true;
        }
      }
    }
    if (wantEnabled && !found) {
      lines.push('addappid(' + id + ")" + (dlc.label ? " -- " + dlc.label : ""));
      changed = true;
    }
  }

  const depotId = String(request.depotId || "");
  const manifestId = String(request.manifestId || "");
  if (depotId && manifestId && /^\d+$/.test(depotId) && /^\d+$/.test(manifestId)) {
    const activeRe = new RegExp("^(\\s*)setmanifestid\\s*\\(\\s*" + depotId + "\\s*,", "i");
    const commentedRe = new RegExp("^(\\s*)--\\s*setmanifestid\\s*\\(\\s*" + depotId + "\\s*,", "i");
    let found = false;
    for (let i = 0; i < lines.length; i++) {
      if (activeRe.test(lines[i]) || commentedRe.test(lines[i])) {
        lines[i] = (lines[i].match(/^(\s*)/)[1] || "") + 'setManifestid(' + depotId + ', "' + manifestId + '")';
        changed = true;
        found = true;
      }
    }
    if (!found) {
      lines.push('setManifestid(' + depotId + ', "' + manifestId + '")');
      changed = true;
    }
  }

  if (changed) fs.writeFileSync(scriptPath, lines.join(newline), "utf8");

  // rescan
  text = fs.readFileSync(scriptPath, "utf8");
  const outLines = text.split(/\r\n|\n|\r/);
  const dlcs = [];
  const dlcMap = {};
  const activeManifestDepotIds = [];
  let luaDepotId = "";
  let luaManifestId = "";
  let updatesLocked = false;
  for (const line of outLines) {
    const lower = line.toLowerCase();
    const commentedDlc = lower.match(/^\s*--\s*addappid\s*\(\s*(\d+)/);
    const activeDlc = commentedDlc ? null : lower.match(/^\s*addappid\s*\(\s*(\d+)/);
    const dlcId = (activeDlc || commentedDlc) ? (activeDlc || commentedDlc)[1] : null;
    if (dlcId && dlcId !== appid) {
      if (!dlcMap[dlcId]) {
        dlcMap[dlcId] = { id: dlcId, enabled: !!activeDlc, label: "" };
        dlcs.push(dlcMap[dlcId]);
      } else if (activeDlc) dlcMap[dlcId].enabled = true;
    }
    const commentedM = lower.match(/^\s*--\s*setmanifestid\s*\(\s*(\d+)\s*,\s*["']?(\d+)/);
    const activeM = commentedM ? null : lower.match(/^\s*setmanifestid\s*\(\s*(\d+)\s*,\s*["']?(\d+)/);
    if (activeM) {
      activeManifestDepotIds.push(activeM[1]);
      if (!luaDepotId) { luaDepotId = activeM[1]; luaManifestId = activeM[2]; updatesLocked = true; }
    } else if (commentedM && !luaDepotId) {
      luaDepotId = commentedM[1];
      luaManifestId = commentedM[2];
    }
  }

  writeText(resultPath, JSON.stringify({
    success: true,
    data: {
      changed,
      dlcs,
      activeManifestDepotIds,
      luaDepotId,
      luaManifestId,
      updatesLocked
    },
    error: ""
  }));
} catch (e) {
  writeText(resultPath, JSON.stringify({ success: false, data: {}, error: e && e.message ? e.message : String(e) }));
}
