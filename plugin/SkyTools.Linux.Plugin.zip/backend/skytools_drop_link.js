#!/usr/bin/env node
"use strict";
const fs = require("fs");
const path = require("path");
const https = require("https");
const http = require("http");

function arg(i) { return process.argv.length > i + 2 ? String(process.argv[i + 2]) : ""; }
function ensureDir(p) { if (p) fs.mkdirSync(p, { recursive: true }); }
function writeText(p, text) { ensureDir(path.dirname(p)); fs.writeFileSync(p, String(text || ""), "utf8"); }

function requestJson(url) {
  return new Promise((resolve, reject) => {
    const mod = url.startsWith("https") ? https : http;
    const req = mod.get(url, {
      headers: { "User-Agent": "SkyToolsPlugin/1.5.1-Millennium", Accept: "application/json,*/*" },
      timeout: 15000
    }, (res) => {
      let data = "";
      res.on("data", (c) => { data += c; });
      res.on("end", () => {
        if (res.statusCode < 200 || res.statusCode >= 300) return reject(new Error("HTTP " + res.statusCode));
        try { resolve(JSON.parse(data || "{}")); } catch (e) { reject(e); }
      });
    });
    req.on("error", reject);
    req.on("timeout", () => { try { req.destroy(); } catch (_) {} reject(new Error("timeout")); });
  });
}

async function main() {
  const url = arg(0);
  const resultPath = arg(1);
  if (!resultPath) throw new Error("Caminho de resultado ausente.");
  const match = String(url || "").match(/store\.steampowered\.com\/app\/(\d+)/i);
  if (!match) throw new Error("Link da Steam inválido.");
  const appId = match[1];
  const data = await requestJson("https://store.steampowered.com/api/appdetails?filters=basic&appids=" + appId);
  if (!data || !data[appId] || !data[appId].success || !data[appId].data) {
    throw new Error("Não foi possível obter dados do AppID " + appId + ".");
  }
  const info = data[appId].data;
  const type = String(info.type || "game").toLowerCase();
  const name = String(info.name || ("AppID " + appId));
  let parentAppId = "";
  let parentName = "";
  if (type === "dlc" && info.fullgame && info.fullgame.appid) {
    parentAppId = String(info.fullgame.appid);
    parentName = String(info.fullgame.name || "");
  }
  writeText(resultPath, JSON.stringify({
    success: true,
    data: {
      type: type === "dlc" ? "dlc" : "game",
      appId: Number(appId),
      name,
      parentAppId: parentAppId ? Number(parentAppId) : 0,
      parentName
    },
    error: ""
  }));
}

main().catch((e) => {
  try {
    writeText(arg(1), JSON.stringify({ success: false, error: e && e.message ? e.message : String(e) }));
  } catch (_) {}
});
