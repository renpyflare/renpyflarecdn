#!/usr/bin/env node
"use strict";
const fs = require("fs");
const path = require("path");
const https = require("https");
const http = require("http");

function arg(i) { return process.argv.length > i + 2 ? String(process.argv[i + 2]) : ""; }
function ensureDir(p) { if (p) fs.mkdirSync(p, { recursive: true }); }
function writeText(p, text) { ensureDir(path.dirname(p)); fs.writeFileSync(p, String(text || ""), "utf8"); }

const repoRawRoot = "https://github.com/skyflarefox/fix/releases/download/fix/";
const releaseApiUrl = "https://api.github.com/repos/skyflarefox/fix/releases/tags/fix";

function requestJson(url) {
  return new Promise((resolve, reject) => {
    const mod = url.startsWith("https") ? https : http;
    const full = url + (url.indexOf("?") >= 0 ? "&" : "?") + "skytools=" + Date.now();
    const req = mod.get(full, {
      headers: {
        "User-Agent": "SkyToolsPlugin/1.5.1-Millennium",
        Accept: "application/vnd.github+json",
        "Cache-Control": "no-cache"
      },
      timeout: 20000
    }, (res) => {
      let data = "";
      res.on("data", (c) => { data += c; });
      res.on("end", () => {
        if (res.statusCode < 200 || res.statusCode >= 300) return reject(new Error("GitHub respondeu HTTP " + res.statusCode));
        try { resolve(JSON.parse(data || "{}")); } catch (e) { reject(e); }
      });
    });
    req.on("error", reject);
    req.on("timeout", () => { try { req.destroy(); } catch (_) {} reject(new Error("timeout")); });
  });
}

function formatSize(bytes) {
  const value = Number(bytes || 0);
  if (!isFinite(value) || value <= 0) return "";
  return (value / 1024 / 1024).toFixed(1).replace(".", ",") + " MB";
}

function typeLabel(kind) {
  return kind === "online" ? "Online" : "Genérica";
}

async function loadRelease() {
  return requestJson(releaseApiUrl);
}

function parseAssets(release) {
  const byAppId = {};
  const assets = Array.isArray(release.assets) ? release.assets : [];
  for (const asset of assets) {
    const fileName = String(asset.name || "");
    const match = /^(\d+)_(online|generic)\.(zip|rar|7z)$/i.exec(fileName);
    if (!match) continue;
    const appId = match[1];
    if (!byAppId[appId]) byAppId[appId] = { appId, assets: [] };
    byAppId[appId].assets.push({
      fileName,
      kind: String(match[2] || "").toLowerCase(),
      downloadUrl: String(asset.browser_download_url || (repoRawRoot + fileName)),
      sizeBytes: Number(asset.size || 0) || 0,
      size: formatSize(asset.size)
    });
  }
  return byAppId;
}

async function main() {
  const resultPath = arg(0);
  const appid = arg(1);
  const gameName = arg(2);
  const kind = String(arg(3) || "").toLowerCase();
  if (!resultPath) throw new Error("Caminho de resultado ausente.");

  const release = await loadRelease();
  const byAppId = parseAssets(release);

  if (kind === "__catalog__" || appid === "__catalog__") {
    const games = Object.keys(byAppId).sort((a, b) => Number(a) - Number(b)).map((id) => ({
      appId: id,
      assets: byAppId[id].assets
    }));
    writeText(resultPath, JSON.stringify({
      success: true,
      data: {
        tag: release.tag_name || "fix",
        releaseUpdatedAt: release.updated_at || "",
        fetchedAt: Date.now(),
        releaseAssetCount: (release.assets || []).length,
        fixAssetCount: games.reduce((n, g) => n + g.assets.length, 0),
        availableAppIds: games.map((g) => g.appId),
        games
      },
      error: ""
    }));
    return;
  }

  const entry = byAppId[String(appid)] || { assets: [] };
  const sources = [];
  for (const asset of entry.assets) {
    if (kind && kind !== asset.kind) continue;
    const label = typeLabel(asset.kind);
    const name = gameName || ("AppID " + appid);
    sources.push({
      name,
      displayName: name + " - " + label + (asset.size ? " - " + asset.size : "") + " (Sky)",
      type: label,
      kind: asset.kind,
      provider: "Sky",
      downloadUrl: asset.downloadUrl,
      fileName: asset.fileName,
      size: asset.size,
      sizeBytes: asset.sizeBytes,
      action: "apply"
    });
  }
  writeText(resultPath, JSON.stringify({ success: true, data: { sources }, error: "" }));
}

main().catch((e) => {
  try {
    writeText(arg(0), JSON.stringify({ success: false, error: e && e.message ? e.message : String(e) }));
  } catch (_) {}
});
