#!/usr/bin/env node
"use strict";
const fs = require("fs");
const path = require("path");
const { execFileSync } = require("child_process");

function arg(i) { return process.argv.length > i + 2 ? String(process.argv[i + 2]) : ""; }
function ensureDir(p) { if (p) fs.mkdirSync(p, { recursive: true }); }
function writeText(p, text) { ensureDir(path.dirname(p)); fs.writeFileSync(p, String(text || ""), "utf8"); }
function readJson(p, fallback) {
  try { return JSON.parse(fs.readFileSync(p, "utf8")); } catch (_) { return fallback; }
}

const dataRoot = arg(0);
const steamPath = arg(1);
const scriptDir = arg(2);
const requestPath = arg(3);
const resultPath = arg(4);

function collectFiles(root, extRe, out) {
  if (!fs.existsSync(root)) return out;
  const st = fs.statSync(root);
  if (st.isFile()) {
    if (extRe.test(root)) out.push(root);
    return out;
  }
  for (const name of fs.readdirSync(root)) {
    collectFiles(path.join(root, name), extRe, out);
  }
  return out;
}

function extractArchive(archive, dest) {
  ensureDir(dest);
  try {
    execFileSync("unzip", ["-o", "-q", archive, "-d", dest], { stdio: "ignore" });
    return true;
  } catch (_) {}
  try {
    execFileSync("tar", ["-xf", archive, "-C", dest], { stdio: "ignore" });
    return true;
  } catch (_) {}
  return false;
}

function appIdFromLua(text) {
  const m = String(text || "").match(/addappid\s*\(\s*(\d+)/i);
  return m ? m[1] : "";
}

function countDlcs(text, appid) {
  const ids = {};
  const re = /addappid\s*\(\s*(\d+)/gi;
  let m;
  while ((m = re.exec(text))) {
    if (m[1] !== String(appid)) ids[m[1]] = true;
  }
  return Object.keys(ids).length;
}

try {
  if (!dataRoot || !scriptDir || !requestPath || !resultPath) throw new Error("Parâmetros insuficientes.");
  ensureDir(scriptDir);
  ensureDir(dataRoot);
  const request = readJson(requestPath, {});
  const files = Array.isArray(request.files) ? request.files : [];
  const games = [];
  const tempRoot = path.join(dataRoot, "drop-import-temp-" + Date.now());
  ensureDir(tempRoot);

  for (const file of files) {
    if (!file || !fs.existsSync(file)) continue;
    const lower = file.toLowerCase();
    if (lower.endsWith(".lua")) {
      const text = fs.readFileSync(file, "utf8");
      const appid = appIdFromLua(text);
      if (!appid) continue;
      const dest = path.join(scriptDir, appid + ".lua");
      fs.copyFileSync(file, dest);
      games.push({ appId: Number(appid), scriptPath: dest, dlcCount: countDlcs(text, appid) });
    } else if (/\.(zip|rar|7z)$/i.test(lower)) {
      const extractDir = path.join(tempRoot, path.basename(file) + "-x");
      if (!extractArchive(file, extractDir)) continue;
      const luas = collectFiles(extractDir, /\.lua$/i, []);
      for (const lua of luas) {
        const text = fs.readFileSync(lua, "utf8");
        const appid = appIdFromLua(text);
        if (!appid) continue;
        const dest = path.join(scriptDir, appid + ".lua");
        fs.copyFileSync(lua, dest);
        games.push({ appId: Number(appid), scriptPath: dest, dlcCount: countDlcs(text, appid) });
      }
      const manifests = collectFiles(extractDir, /\.manifest$/i, []);
      const depotCache = path.join(steamPath || "", "config", "depotcache");
      if (manifests.length && steamPath) {
        ensureDir(depotCache);
        for (const mf of manifests) {
          try { fs.copyFileSync(mf, path.join(depotCache, path.basename(mf))); } catch (_) {}
        }
      }
    } else if (lower.endsWith(".manifest") && steamPath) {
      const depotCache = path.join(steamPath, "config", "depotcache");
      ensureDir(depotCache);
      fs.copyFileSync(file, path.join(depotCache, path.basename(file)));
    }
  }

  try { fs.rmSync(tempRoot, { recursive: true, force: true }); } catch (_) {}

  writeText(resultPath, JSON.stringify({
    success: true,
    data: {
      games,
      message: games.length ? (games.length + " arquivo(s) adicionados.") : "Nenhum jogo válido encontrado nos arquivos."
    },
    error: ""
  }));
} catch (e) {
  writeText(resultPath, JSON.stringify({ success: false, error: e && e.message ? e.message : String(e) }));
}
