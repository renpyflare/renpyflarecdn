#!/usr/bin/env node
"use strict";
const fs = require("fs");
const path = require("path");

function arg(i) { return process.argv.length > i + 2 ? String(process.argv[i + 2]) : ""; }
function ensureDir(p) { if (p) fs.mkdirSync(p, { recursive: true }); }
function writeText(p, text) { ensureDir(path.dirname(p)); fs.writeFileSync(p, String(text || ""), "utf8"); }

function parseLuaState(filePath, appid) {
  const state = {
    gameName: "",
    dlcCount: 0,
    dlcAppIds: [],
    dlcs: [],
    manifestEntries: [],
    activeManifestDepotIds: [],
    luaDepotId: "",
    luaManifestId: "",
    updatesLocked: false
  };
  let text;
  try { text = fs.readFileSync(filePath, "utf8"); } catch (_) { return state; }
  text = text.replace(/--\[\[[\s\S]*?\]\]/g, "");
  const lines = text.replace(/\r\n/g, "\n").replace(/\r/g, "\n").split("\n");
  const dlcMap = {};
  const manifests = [];
  const seenActive = {};
  const root = String(appid);

  for (const line of lines) {
    const lower = line.toLowerCase();
    let commentedDlc = lower.match(/^\s*--\s*addappid\s*\(\s*(\d+)/);
    let activeDlc = commentedDlc ? null : lower.match(/^\s*addappid\s*\(\s*(\d+)/);
    const dlcId = (activeDlc || commentedDlc) ? (activeDlc || commentedDlc)[1] : null;
    if (dlcId && dlcId !== root) {
      const label = (line.match(/\)\s*--\s*(.*?)\s*$/) || [])[1] || "";
      if (!dlcMap[dlcId]) {
        dlcMap[dlcId] = { id: dlcId, enabled: !!activeDlc, label };
        state.dlcs.push(dlcMap[dlcId]);
      } else if (activeDlc) dlcMap[dlcId].enabled = true;
    }
    let commentedM = lower.match(/^\s*--\s*setmanifestid\s*\(\s*(\d+)\s*,\s*["']?(\d+)/);
    let activeM = commentedM ? null : lower.match(/^\s*setmanifestid\s*\(\s*(\d+)\s*,\s*["']?(\d+)/);
    const depotId = (activeM || commentedM) ? (activeM || commentedM)[1] : null;
    const manifestId = (activeM || commentedM) ? (activeM || commentedM)[2] : null;
    if (depotId && manifestId) {
      manifests.push({ depotId, manifestId, enabled: !!activeM });
      if (activeM && !seenActive[depotId]) {
        seenActive[depotId] = true;
        state.activeManifestDepotIds.push(depotId);
      }
    }
    if (!state.gameName) {
      const gm = line.match(/^\s*--\s*Game\s*:\s*(.+?)\s*$/i) || line.match(/^\s*--\s*\d+\s*-\s*(.+?)\s*$/);
      if (gm) state.gameName = gm[1].trim();
    }
  }
  for (const d of state.dlcs) if (d.enabled) state.dlcAppIds.push(d.id);
  state.dlcCount = state.dlcAppIds.length;
  state.manifestEntries = manifests;
  const preferred = String(Number(appid) + 1);
  let selected = manifests.find((m) => m.depotId === preferred) || manifests.find((m) => !dlcMap[m.depotId]) || manifests[0];
  if (selected) {
    state.luaDepotId = selected.depotId;
    state.luaManifestId = selected.manifestId;
    state.updatesLocked = selected.enabled === true;
  }
  return state;
}

try {
  const resultPath = arg(0);
  if (!resultPath) throw new Error("Caminho de resultado ausente.");
  const items = [];
  const seen = {};
  for (let i = 1; i < process.argv.length - 2; i++) {
    const dir = arg(i);
    if (!dir || !fs.existsSync(dir)) continue;
    let entries;
    try { entries = fs.readdirSync(dir); } catch (_) { continue; }
    for (const name of entries) {
      const m = name.match(/^(\d+)\.lua(\.disabled)?$/i);
      if (!m) continue;
      const appid = m[1];
      if (seen[appid]) continue;
      seen[appid] = true;
      const fullPath = path.join(dir, name);
      const state = parseLuaState(fullPath, appid);
      items.push({
        appId: Number(appid),
        appid: Number(appid),
        gameName: state.gameName || ("AppID " + appid),
        name: state.gameName || ("AppID " + appid),
        fileName: name,
        fullPath,
        scriptDirectory: dir,
        dlcCount: state.dlcCount,
        dlcAppIds: state.dlcAppIds,
        dlcs: state.dlcs,
        manifestEntries: state.manifestEntries,
        activeManifestDepotIds: state.activeManifestDepotIds,
        luaDepotId: state.luaDepotId,
        luaManifestId: state.luaManifestId,
        updatesLocked: state.updatesLocked,
        isDisabled: /\.disabled$/i.test(name)
      });
    }
  }
  items.sort((a, b) => a.appId - b.appId);
  writeText(resultPath, JSON.stringify({ success: true, data: items, error: "" }));
} catch (e) {
  writeText(arg(0), JSON.stringify({ success: false, error: e && e.message ? e.message : String(e) }));
}
