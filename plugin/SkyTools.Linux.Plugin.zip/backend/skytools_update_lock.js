#!/usr/bin/env node
"use strict";
const fs = require("fs");
const path = require("path");

function arg(i) { return process.argv.length > i + 2 ? String(process.argv[i + 2]) : ""; }
function ensureDir(p) { if (p) fs.mkdirSync(p, { recursive: true }); }
function writeText(p, text) { ensureDir(path.dirname(p)); fs.writeFileSync(p, String(text || ""), "utf8"); }
function writeResult(resultPath, success, data, error) {
  writeText(resultPath, JSON.stringify({ success, data: typeof data === "string" ? JSON.parse(data) : data, error: error || "" }));
}

const resultPath = arg(0);
const scriptPath = arg(1);
const requestedLocked = String(arg(2)).toLowerCase() === "true";
const depotId = String(arg(3) || "");
const manifestId = String(arg(4) || "");

try {
  if (!resultPath) throw new Error("Caminho de resultado ausente.");
  if (!scriptPath || !fs.existsSync(scriptPath)) throw new Error("Arquivo Lua do jogo não encontrado.");
  if (!/^\d+$/.test(depotId)) throw new Error("DepotID inválido.");
  if (!/^\d+$/.test(manifestId)) throw new Error("ManifestID inválido.");

  let original = fs.readFileSync(scriptPath, "utf8");
  const newline = original.indexOf("\r\n") >= 0 ? "\r\n" : "\n";
  let lines = original.split(/\r\n|\n|\r/);
  const activePattern = new RegExp("^(\\s*)setmanifestid\\s*\\(\\s*" + depotId + "\\s*,[^\\r\\n]*$", "i");
  const commentedPattern = new RegExp("^(\\s*)--\\s*setmanifestid\\s*\\(\\s*" + depotId + "\\s*,[^\\r\\n]*$", "i");
  let changed = false;
  let found = false;

  for (let i = 0; i < lines.length; i++) {
    const active = lines[i].match(activePattern);
    const commented = lines[i].match(commentedPattern);
    if (requestedLocked && (active || commented)) {
      if (commented) {
        const indent = commented[1] || "";
        let uncommented = lines[i].slice(indent.length + 2);
        if (/^[ \t]/.test(uncommented)) uncommented = uncommented.slice(1);
        lines[i] = indent + uncommented;
        changed = true;
      }
      found = true;
    } else if (!requestedLocked && active) {
      lines[i] = active[1] + "-- " + lines[i].slice(active[1].length);
      changed = true;
      found = true;
    }
  }

  if (requestedLocked && !found) {
    const replacement = 'setManifestid(' + depotId + ', "' + manifestId + '")';
    const body = lines.join(newline);
    if (!/\n$/.test(body) && body.length) {
      original = body + newline + replacement + newline;
    } else {
      original = body + replacement + newline;
    }
    changed = true;
  } else {
    original = lines.join(newline);
  }

  if (changed) fs.writeFileSync(scriptPath, original, "utf8");
  const finalText = fs.readFileSync(scriptPath, "utf8");
  const locked = new RegExp("^\\s*setmanifestid\\s*\\(\\s*" + depotId + "\\s*,", "im").test(finalText);
  if (locked !== requestedLocked) throw new Error("A alteração do bloqueio não foi confirmada no arquivo Lua.");

  writeResult(resultPath, true, { locked, changed, depotId, manifestId }, "");
} catch (e) {
  writeResult(resultPath, false, {}, e && e.message ? e.message : String(e));
}
