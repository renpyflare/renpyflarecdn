#!/usr/bin/env node
"use strict";
const fs = require("fs");
const path = require("path");
function arg(i) { return process.argv.length > i + 2 ? String(process.argv[i + 2]) : ""; }
function ensureDir(p) { if (p) fs.mkdirSync(p, { recursive: true }); }
function writeText(p, text) { ensureDir(path.dirname(p)); fs.writeFileSync(p, String(text || ""), "utf8"); }
const resultPath = arg(0);
const removed = [];
const remaining = [];
try {
  for (let i = 1; i < process.argv.length - 2; i++) {
    const p = arg(i);
    if (!p) continue;
    try { if (fs.existsSync(p) && fs.statSync(p).isFile()) fs.unlinkSync(p); } catch (_) {}
    if (fs.existsSync(p)) remaining.push(p); else removed.push(p);
  }
  const success = remaining.length === 0;
  writeText(resultPath, JSON.stringify({
    success,
    data: { removedPaths: removed, remainingPaths: remaining },
    error: success ? "" : "Não foi possível apagar: " + remaining.join(", ")
  }));
} catch (e) {
  writeText(resultPath, JSON.stringify({ success: false, error: e && e.message ? e.message : String(e) }));
}
