#!/usr/bin/env node
"use strict";
const fs = require("fs");
const path = require("path");
const https = require("https");
const http = require("http");
const { execFileSync, spawnSync } = require("child_process");

function arg(i) {
  // process.argv: [node, script, ...args]
  return process.argv.length > i + 2 ? String(process.argv[i + 2]) : "";
}

const dataRoot = arg(0);
const steamPath = arg(1);
const scriptDir = arg(2);
const appId = arg(3);
const gameName = arg(4);
let preferred = arg(5) || "Automatic";
let morrenusKey = arg(6);
const resultPath = arg(7);
const targetDlcId = arg(8);
const targetDlcName = arg(9);
if (morrenusKey === "-") morrenusKey = "";

function ensureDir(p) {
  if (p) fs.mkdirSync(p, { recursive: true });
}
function writeText(p, text) {
  ensureDir(path.dirname(p));
  fs.writeFileSync(p, String(text || ""), "utf8");
}
function readText(p) {
  try { return fs.readFileSync(p, "utf8"); } catch (_) { return ""; }
}
function readJson(p, fallback) {
  try { return JSON.parse(fs.readFileSync(p, "utf8")); } catch (_) { return fallback; }
}
function removeTree(p) {
  try { fs.rmSync(p, { recursive: true, force: true }); } catch (_) {}
}
function writeResult(payload) {
  writeText(resultPath, JSON.stringify(payload));
}
function combine(a, b) {
  return path.join(String(a || ""), String(b || ""));
}
function replaceAll(text, token, value) {
  return String(text || "").split(String(token)).join(String(value == null ? "" : value));
}
function canonicalSourceId(id) {
  const lower = String(id || "").toLowerCase();
  if (lower === "sushi" || lower === "ryzenapi" || lower === "greenhill") return "ryzen";
  return String(id || "");
}
preferred = canonicalSourceId(preferred);

function download(url, headers, target) {
  return new Promise((resolve, reject) => {
    const attempt = (currentUrl, left) => {
      const mod = currentUrl.startsWith("https") ? https : http;
      const req = mod.get(currentUrl, {
        headers: Object.assign({
          "User-Agent": "SkyToolsPlugin/1.5.1-Millennium",
          Accept: "application/zip,application/octet-stream,*/*"
        }, headers || {}),
        timeout: 60000
      }, (res) => {
        if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
          res.resume();
          return attempt(res.headers.location, left);
        }
        if (res.statusCode < 200 || res.statusCode >= 300) {
          res.resume();
          if (left > 0) return attempt(currentUrl, left - 1);
          return reject(new Error("HTTP " + res.statusCode + " em " + currentUrl));
        }
        ensureDir(path.dirname(target));
        const out = fs.createWriteStream(target);
        res.pipe(out);
        out.on("finish", () => resolve());
        out.on("error", reject);
      });
      req.on("error", (err) => {
        if (left > 0) attempt(currentUrl, left - 1);
        else reject(err);
      });
      req.on("timeout", () => {
        try { req.destroy(); } catch (_) {}
        if (left > 0) attempt(currentUrl, left - 1);
        else reject(new Error("timeout"));
      });
    };
    // Prefer curl if available (better TLS on some systems)
    try {
      ensureDir(path.dirname(target));
      const r = spawnSync("curl", ["-fsSL", "-A", "SkyToolsPlugin/1.5.1-Millennium", "-o", target, url], {
        stdio: "ignore",
        timeout: 120000
      });
      if (r.status === 0 && fs.existsSync(target) && fs.statSync(target).size > 0) return resolve();
    } catch (_) {}
    attempt(url, 2);
  });
}

function extractZip(zipPath, targetDir) {
  removeTree(targetDir);
  ensureDir(targetDir);
  try {
    execFileSync("unzip", ["-o", "-q", zipPath, "-d", targetDir], { stdio: "ignore", timeout: 120000 });
    return true;
  } catch (_) {}
  try {
    execFileSync("tar", ["-xf", zipPath, "-C", targetDir], { stdio: "ignore", timeout: 120000 });
    return true;
  } catch (_) {}
  return false;
}

function collectFiles(root, re, out) {
  if (!fs.existsSync(root)) return out;
  const st = fs.statSync(root);
  if (st.isFile()) {
    if (re.test(root)) out.push(root);
    return out;
  }
  let entries;
  try { entries = fs.readdirSync(root); } catch (_) { return out; }
  for (const name of entries) collectFiles(path.join(root, name), re, out);
  return out;
}

function countDlcs(text, appid) {
  const ids = {};
  const re = /addappid\s*\(\s*(\d+)/gi;
  let m;
  while ((m = re.exec(String(text || "")))) {
    if (m[1] !== String(appid)) ids[m[1]] = true;
  }
  return Object.keys(ids).length;
}

function isDisabled(settings, id) {
  const disabled = settings && settings.DisabledApiIds ? settings.DisabledApiIds : [];
  if (!Array.isArray(disabled)) return false;
  return disabled.some((x) => String(x).toLowerCase() === String(id).toLowerCase());
}

function nativeOverride(settings, id) {
  const overrides = (settings && settings.NativeManifestApis) || {};
  return overrides[id] || overrides[String(id).toLowerCase()] || {};
}

function nativeSource(settings, id, name, urlTemplate, apiKey) {
  const override = nativeOverride(settings, id);
  if (isDisabled(settings, id) || override.enabled === false) return null;
  const source = {
    id,
    name: override.name || name,
    apiKey: override.apiKey || apiKey || "",
    urlTemplate: override.urlTemplate || urlTemplate,
    useProxy: override.useProxy === true,
    proxyUrlTemplate: override.proxyUrlTemplate || "",
    headers: override.headers || null
  };
  if (!source.urlTemplate || String(source.urlTemplate).indexOf("<appid>") < 0) return null;
  if (id === "morrenus" && !source.apiKey) return null;
  return source;
}

function loadSources() {
  const settings = readJson(path.join(dataRoot, "settings.json"), {});
  const sources = [];
  const greenhill = nativeSource(settings, "ryzen", "GreenHill", "https://api.ryzennetworking.duckdns.org/api/download/<appid>", "");
  const skyapi = nativeSource(settings, "skyapi", "SkyAPI", "https://raw.githubusercontent.com/skyflarefox/Skyapi/main/<appid>.zip", "");
  const morrenus = nativeSource(settings, "morrenus", "Morrenus", "https://hubcapmanifest.com/api/v1/manifest/<appid>?api_key=<moapikey>", morrenusKey);
  if (greenhill) {
    greenhill.name = "GreenHill";
    greenhill.urlTemplate = "https://api.ryzennetworking.duckdns.org/api/download/<appid>";
    sources.push(greenhill);
  }
  if (skyapi) sources.push(skyapi);
  if (morrenus) sources.push(morrenus);

  const custom = settings.CustomManifestApis;
  if (Array.isArray(custom)) {
    for (let i = 0; i < custom.length; i++) {
      const item = custom[i] || {};
      if (item.enabled === false || !item.urlTemplate || String(item.urlTemplate).indexOf("<appid>") < 0) continue;
      sources.push({
        id: item.id || ("custom-" + i),
        name: item.name || ("API " + (i + 1)),
        urlTemplate: item.urlTemplate,
        apiKey: item.apiKey || "",
        useProxy: item.useProxy === true,
        proxyUrlTemplate: item.proxyUrlTemplate || "",
        headers: item.headers || null
      });
    }
  }

  let apiOrder = settings.ApiOrder || ["ryzen", "skyapi", "morrenus"];
  if (!Array.isArray(apiOrder)) apiOrder = ["ryzen", "skyapi", "morrenus"];
  apiOrder = apiOrder.slice();
  for (let g = apiOrder.length - 1; g >= 0; g--) {
    if (canonicalSourceId(apiOrder[g]).toLowerCase() === "ryzen") apiOrder.splice(g, 1);
  }
  apiOrder.unshift("ryzen");
  const ranked = {};
  apiOrder.forEach((id, idx) => { ranked[canonicalSourceId(id).toLowerCase()] = idx; });
  sources.sort((a, b) => {
    const la = ranked[String(a.id).toLowerCase()];
    const ra = ranked[String(b.id).toLowerCase()];
    return (la == null ? 9999 : la) - (ra == null ? 9999 : ra);
  });

  if (preferred && preferred !== "Automatic") {
    const ordered = [];
    for (const s of sources) if (String(s.id).toLowerCase() === String(preferred).toLowerCase()) ordered.push(s);
    for (const s of sources) if (String(s.id).toLowerCase() !== String(preferred).toLowerCase()) ordered.push(s);
    return ordered;
  }
  if (settings.AutomaticSourceFallback === false && sources.length > 1) return [sources[0]];
  return sources;
}

function sourceUrl(api) {
  let url = replaceAll(api.urlTemplate, "<appid>", appId);
  url = replaceAll(url, "<moapikey>", morrenusKey);
  url = replaceAll(url, "<apikey>", api.apiKey || "");
  if (api.useProxy && api.proxyUrlTemplate && String(api.proxyUrlTemplate).indexOf("<url>") >= 0) {
    url = replaceAll(api.proxyUrlTemplate, "<url>", encodeURIComponent(url));
  }
  return url;
}

function chooseScript(luaFiles) {
  if (!luaFiles.length) return null;
  const preferredName = appId + ".lua";
  for (const f of luaFiles) {
    if (path.basename(f).toLowerCase() === preferredName.toLowerCase()) return f;
  }
  return luaFiles[0];
}

function installFromZip(zipPath, sourceName) {
  const tempDir = path.join(dataRoot, "skytools-install-extract-" + appId + "-" + Date.now());
  try {
    if (!extractZip(zipPath, tempDir)) throw new Error("Não foi possível extrair o pacote.");
    const luaFiles = collectFiles(tempDir, /\.lua$/i, []);
    const manifestFiles = collectFiles(tempDir, /\.manifest$/i, []);
    if (!luaFiles.length && !manifestFiles.length) throw new Error("Pacote sem arquivos .lua ou .manifest.");

    const scriptSource = chooseScript(luaFiles);
    let scriptText = scriptSource ? readText(scriptSource) : "";
    if (!scriptText && luaFiles.length) scriptText = readText(luaFiles[0]);
    if (!scriptText) {
      // minimal lua if only manifests
      scriptText = "addappid(" + appId + ")\n";
      for (const mf of manifestFiles) {
        const m = path.basename(mf).match(/^(\d+)_(\d+)\.manifest$/i);
        if (m) scriptText += 'setManifestid(' + m[1] + ', "' + m[2] + '")\n';
      }
    }

    // place manifests into depotcache
    const depotCache = path.join(steamPath, "config", "depotcache");
    const installedFiles = [];
    if (manifestFiles.length) {
      ensureDir(depotCache);
      for (const mf of manifestFiles) {
        const dest = path.join(depotCache, path.basename(mf));
        let previous = "";
        if (fs.existsSync(dest)) {
          previous = path.join(dataRoot, "manifest-backups", appId, path.basename(mf));
          ensureDir(path.dirname(previous));
          try { fs.copyFileSync(dest, previous); } catch (_) {}
        }
        fs.copyFileSync(mf, dest);
        installedFiles.push({ InstalledPath: dest, PreviousBackup: previous });
      }
    }

    ensureDir(scriptDir);
    const scriptDestination = path.join(scriptDir, appId + ".lua");
    let previousScriptBackup = "";
    if (fs.existsSync(scriptDestination)) {
      previousScriptBackup = path.join(dataRoot, "manifest-backups", appId, appId + ".lua.bak");
      ensureDir(path.dirname(previousScriptBackup));
      try { fs.copyFileSync(scriptDestination, previousScriptBackup); } catch (_) {}
    }
    writeText(scriptDestination, scriptText);

    const dlcCount = countDlcs(scriptText, appId);
    const recordsPath = path.join(dataRoot, "manifest-installs.json");
    let records = readJson(recordsPath, []);
    if (!Array.isArray(records)) records = [];
    records = records.filter((r) => String((r || {}).AppId || (r || {}).appId || "") !== String(appId));
    const cleanGameName = String(gameName || "").trim();
    records.push({
      AppId: Number(appId),
      GameName: cleanGameName,
      SourceName: sourceName,
      InstalledAt: new Date().toISOString(),
      SourcePackage: sourceName,
      ScriptPath: scriptDestination,
      PreviousScriptBackup: previousScriptBackup,
      ManifestFiles: installedFiles
    });
    writeText(recordsPath, JSON.stringify(records));

    if (cleanGameName && !/^\d+$/.test(cleanGameName)) {
      const cachePath = path.join(dataRoot, "skytools-app-name-cache.json");
      const cache = readJson(cachePath, {}) || {};
      cache[String(appId)] = { AppId: Number(appId), Name: cleanGameName };
      writeText(cachePath, JSON.stringify(cache));
    }

    return {
      appId: Number(appId),
      gameName: cleanGameName || gameName,
      scriptPath: scriptDestination,
      manifestCount: manifestFiles.length,
      dlcCount,
      sourceName,
      warnings: [],
      message: "Jogo adicionado via " + sourceName + "."
    };
  } finally {
    removeTree(tempDir);
  }
}

async function main() {
  if (!dataRoot || !steamPath || !scriptDir || !appId || !resultPath) {
    throw new Error("Parâmetros insuficientes para instalar o jogo.");
  }
  ensureDir(dataRoot);
  ensureDir(scriptDir);

  const sources = loadSources();
  if (!sources.length) throw new Error("Nenhuma API de download disponível.");

  const tempZip = path.join(dataRoot, "skytools-download-" + appId + "-" + Date.now() + ".zip");
  const errors = [];
  let result = null;

  for (const source of sources) {
    try {
      removeTree(tempZip);
      await download(sourceUrl(source), source.headers, tempZip);
      if (!fs.existsSync(tempZip) || fs.statSync(tempZip).size < 10) {
        throw new Error("Download vazio.");
      }
      result = installFromZip(tempZip, source.name);
      break;
    } catch (err) {
      errors.push(source.name + ": " + (err && err.message ? err.message : String(err)));
      removeTree(tempZip);
    }
  }
  removeTree(tempZip);

  if (!result) {
    throw new Error(
      (targetDlcId ? "Não foi encontrada uma DLC válida em nenhuma API." : "Não foi encontrado um jogo válido em nenhuma API.") +
      (errors.length ? " " + errors.join(" | ") : "")
    );
  }
  writeResult({ success: true, data: result, error: "" });
}

main().catch((e) => {
  try {
    writeResult({ success: false, error: e && e.message ? e.message : String(e) });
  } catch (_) {}
});
