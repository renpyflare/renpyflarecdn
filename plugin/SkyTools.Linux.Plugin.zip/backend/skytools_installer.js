#!/usr/bin/env node
"use strict";
const fs = require("fs");
const path = require("path");
const https = require("https");
const http = require("http");
const { execFileSync, spawnSync } = require("child_process");

function arg(i) {
  return process.argv.length > i + 2 ? String(process.argv[i + 2]) : "";
}

const dataRoot = arg(0);
const steamPath = arg(1);
const scriptDir = arg(2);
const appId = String(arg(3) || "").trim();
const gameName = arg(4);
let preferred = arg(5);
const morrenusKey = arg(6) === "-" ? "" : arg(6);
const resultPath = arg(7);
const targetDlcId = arg(8) === "-" ? "" : String(arg(8) || "").trim();

function ensureDir(p) {
  fs.mkdirSync(p, { recursive: true });
}
function writeText(p, t) {
  ensureDir(path.dirname(p));
  fs.writeFileSync(p, t, "utf8");
}
function readText(p) {
  try { return fs.readFileSync(p, "utf8"); } catch (_) { return ""; }
}
function readJson(p, fallback) {
  try { return JSON.parse(fs.readFileSync(p, "utf8")); } catch (_) { return fallback; }
}
function removeTree(p) {
  try { fs.rmSync(p, { recursive: true, force: true }); } catch (_) {}
}
function writeResult(payload) {
  writeText(resultPath, JSON.stringify(payload));
}
function combine(a, b) {
  return path.join(String(a || ""), String(b || ""));
}
function canonicalSourceId(id) {
  const lower = String(id || "").toLowerCase();
  if (lower === "sushi" || lower === "ryzenapi" || lower === "greenhill") return "ryzen";
  return String(id || "");
}
preferred = canonicalSourceId(preferred);

function download(url, headers, target) {
  return new Promise((resolve, reject) => {
    const finishOk = () => {
      try {
        if (fs.existsSync(target) && fs.statSync(target).size > 0) return resolve();
      } catch (_) {}
      reject(new Error("Download vazio: " + url));
    };
    try {
      ensureDir(path.dirname(target));
      const r = spawnSync("curl", ["-fsSL", "-A", "SkyToolsPlugin/1.5.1-Linux", "-L", "-o", target, url], {
        stdio: "ignore",
        timeout: 180000
      });
      if (r.status === 0 && fs.existsSync(target) && fs.statSync(target).size > 0) return resolve();
    } catch (_) {}

    const attempt = (currentUrl, left) => {
      const mod = currentUrl.startsWith("https") ? https : http;
      const req = mod.get(currentUrl, {
        headers: Object.assign({
          "User-Agent": "SkyToolsPlugin/1.5.1-Linux",
          Accept: "application/zip,application/octet-stream,*/*"
        }, headers || {}),
        timeout: 90000
      }, (res) => {
        if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
          res.resume();
          return attempt(res.headers.location, left);
        }
        if (res.statusCode < 200 || res.statusCode >= 300) {
          res.resume();
          if (left > 0) return attempt(currentUrl, left - 1);
          return reject(new Error("HTTP " + res.statusCode + " em " + currentUrl));
        }
        ensureDir(path.dirname(target));
        const out = fs.createWriteStream(target);
        res.pipe(out);
        out.on("finish", finishOk);
        out.on("error", reject);
      });
      req.on("error", (err) => {
        if (left > 0) attempt(currentUrl, left - 1);
        else reject(err);
      });
      req.on("timeout", () => {
        try { req.destroy(); } catch (_) {}
        if (left > 0) attempt(currentUrl, left - 1);
        else reject(new Error("timeout"));
      });
    };
    attempt(url, 2);
  });
}

function extractZip(zipPath, targetDir) {
  removeTree(targetDir);
  ensureDir(targetDir);
  try {
    execFileSync("unzip", ["-o", "-q", zipPath, "-d", targetDir], { stdio: "ignore", timeout: 120000 });
    return true;
  } catch (_) {}
  try {
    execFileSync("tar", ["-xf", zipPath, "-C", targetDir], { stdio: "ignore", timeout: 120000 });
    return true;
  } catch (_) {}
  // Python zipfile fallback (always available on most Linux distros)
  try {
    const py = [
      "import zipfile,sys",
      "zipfile.ZipFile(sys.argv[1]).extractall(sys.argv[2])"
    ].join(";");
    execFileSync("python3", ["-c", py, zipPath, targetDir], { stdio: "ignore", timeout: 120000 });
    return true;
  } catch (_) {}
  try {
    const py = [
      "import zipfile,sys",
      "zipfile.ZipFile(sys.argv[1]).extractall(sys.argv[2])"
    ].join(";");
    execFileSync("python", ["-c", py, zipPath, targetDir], { stdio: "ignore", timeout: 120000 });
    return true;
  } catch (_) {}
  return false;
}

function collectFiles(root, re, out) {
  if (!fs.existsSync(root)) return out;
  const st = fs.statSync(root);
  if (st.isFile()) {
    if (re.test(root)) out.push(root);
    return out;
  }
  let entries = [];
  try { entries = fs.readdirSync(root); } catch (_) { return out; }
  for (const name of entries) {
    collectFiles(path.join(root, name), re, out);
  }
  return out;
}

function chooseScript(luaFiles) {
  const preferredName = appId + ".lua";
  for (const f of luaFiles) {
    if (path.basename(f).toLowerCase() === preferredName.toLowerCase()) return f;
  }
  for (const f of luaFiles) {
    if (/^\d+\.lua$/i.test(path.basename(f))) return f;
  }
  return luaFiles[0] || "";
}

function countDlcs(scriptText, mainAppId) {
  const ids = new Set();
  const re = /addappid\s*\(\s*(\d+)/gi;
  let m;
  while ((m = re.exec(String(scriptText || ""))) !== null) {
    const id = m[1];
    if (id !== String(mainAppId)) ids.add(id);
  }
  return ids.size;
}

function loadSources() {
  const sources = [];
  const add = (id, name, url, headers) => {
    sources.push({ id, name, url, headers: headers || {} });
  };
  // GreenHill / Ryzen family
  add("ryzen", "GreenHill", "https://manifest.greenhills.dev/manifest/" + appId, {});
  add("skyapi", "SkyAPI", "https://api.skyapi.lat/manifest/" + appId, {});
  if (morrenusKey) {
    add("morrenus", "Morrenus", "https://api.morrenus.xyz/manifest/" + appId, {
      Authorization: "Bearer " + morrenusKey
    });
  }
  // Reorder by preferred
  const pref = String(preferred || "").toLowerCase();
  if (pref && pref !== "automatic" && pref !== "auto") {
    sources.sort((a, b) => {
      if (a.id === pref) return -1;
      if (b.id === pref) return 1;
      return 0;
    });
  }
  return sources;
}

function sourceUrl(source) {
  return source.url;
}

function placeManifests(manifestFiles) {
  // OpenSteamTools / SteamTools docs:
  // primary: <Steam>/depotcache/*.manifest
  // alternate: <Steam>/config/depotcache/*.manifest
  const targets = [
    path.join(steamPath, "depotcache"),
    path.join(steamPath, "config", "depotcache")
  ];
  const installedFiles = [];
  for (const mf of manifestFiles) {
    const base = path.basename(mf);
    for (const depotCache of targets) {
      ensureDir(depotCache);
      const dest = path.join(depotCache, base);
      let previous = "";
      if (fs.existsSync(dest)) {
        previous = path.join(dataRoot, "manifest-backups", appId, base);
        ensureDir(path.dirname(previous));
        try { fs.copyFileSync(dest, previous); } catch (_) {}
      }
      fs.copyFileSync(mf, dest);
      installedFiles.push({ InstalledPath: dest, PreviousBackup: previous });
    }
  }
  return installedFiles;
}

function installFromZip(zipPath, sourceName) {
  const tempDir = path.join(dataRoot, "skytools-install-extract-" + appId + "-" + Date.now());
  try {
    if (!extractZip(zipPath, tempDir)) throw new Error("Não foi possível extrair o pacote (unzip/tar/python3).");
    const luaFiles = collectFiles(tempDir, /\.lua$/i, []);
    const manifestFiles = collectFiles(tempDir, /\.manifest$/i, []);
    if (!luaFiles.length && !manifestFiles.length) throw new Error("Pacote sem arquivos .lua ou .manifest.");

    const scriptSource = chooseScript(luaFiles);
    let scriptText = scriptSource ? readText(scriptSource) : "";
    if (!scriptText && luaFiles.length) scriptText = readText(luaFiles[0]);
    if (!scriptText) {
      scriptText = "addappid(" + appId + ")\n";
      for (const mf of manifestFiles) {
        const m = path.basename(mf).match(/^(\d+)_(\d+)\.manifest$/i);
        if (m) scriptText += 'setManifestid(' + m[1] + ', "' + m[2] + '")\n';
      }
    }

    // Normalize line endings for Linux OpenSteamTools / SLSsteam
    scriptText = String(scriptText).replace(/\r\n/g, "\n").replace(/\r/g, "\n");
    if (!/addappid\s*\(\s*\d+/i.test(scriptText)) {
      scriptText = "addappid(" + appId + ")\n" + scriptText;
    }

    const installedFiles = placeManifests(manifestFiles);

    ensureDir(scriptDir);
    const scriptDestination = path.join(scriptDir, appId + ".lua");
    let previousScriptBackup = "";
    if (fs.existsSync(scriptDestination)) {
      previousScriptBackup = path.join(dataRoot, "manifest-backups", appId, appId + ".lua.bak");
      ensureDir(path.dirname(previousScriptBackup));
      try { fs.copyFileSync(scriptDestination, previousScriptBackup); } catch (_) {}
    }
    writeText(scriptDestination, scriptText);

    const dlcCount = countDlcs(scriptText, appId);
    const recordsPath = path.join(dataRoot, "manifest-installs.json");
    let records = readJson(recordsPath, []);
    if (!Array.isArray(records)) records = [];
    records = records.filter((r) => String((r || {}).AppId || (r || {}).appId || "") !== String(appId));
    const cleanGameName = String(gameName || "").trim();
    records.push({
      AppId: Number(appId),
      GameName: cleanGameName,
      SourceName: sourceName,
      InstalledAt: new Date().toISOString(),
      SourcePackage: sourceName,
      ScriptPath: scriptDestination,
      PreviousScriptBackup: previousScriptBackup,
      ManifestFiles: installedFiles
    });
    writeText(recordsPath, JSON.stringify(records));

    if (cleanGameName && !/^\d+$/.test(cleanGameName)) {
      const cachePath = path.join(dataRoot, "skytools-app-name-cache.json");
      const cache = readJson(cachePath, {}) || {};
      cache[String(appId)] = { AppId: Number(appId), Name: cleanGameName };
      writeText(cachePath, JSON.stringify(cache));
    }

    return {
      appId: Number(appId),
      gameName: cleanGameName || gameName,
      scriptPath: scriptDestination,
      manifestCount: manifestFiles.length,
      dlcCount,
      sourceName,
      warnings: [],
      message: "Jogo adicionado via " + sourceName + "."
    };
  } finally {
    removeTree(tempDir);
  }
}

async function main() {
  if (!dataRoot || !steamPath || !scriptDir || !appId || !resultPath) {
    throw new Error("Parâmetros insuficientes para instalar o jogo.");
  }
  ensureDir(dataRoot);
  ensureDir(scriptDir);
  // Ensure OpenSteamTools / SteamTools watched dirs exist
  try { ensureDir(path.join(steamPath, "config", "stplug-in")); } catch (_) {}
  try { ensureDir(path.join(steamPath, "config", "lua")); } catch (_) {}
  try { ensureDir(path.join(steamPath, "depotcache")); } catch (_) {}
  try { ensureDir(path.join(steamPath, "config", "depotcache")); } catch (_) {}

  const sources = loadSources();
  if (!sources.length) throw new Error("Nenhuma API de download disponível.");

  const tempZip = path.join(dataRoot, "skytools-download-" + appId + "-" + Date.now() + ".zip");
  const errors = [];
  let result = null;

  for (const source of sources) {
    try {
      removeTree(tempZip);
      await download(sourceUrl(source), source.headers, tempZip);
      if (!fs.existsSync(tempZip) || fs.statSync(tempZip).size < 10) {
        throw new Error("Download vazio.");
      }
      result = installFromZip(tempZip, source.name);
      break;
    } catch (err) {
      errors.push(source.name + ": " + (err && err.message ? err.message : String(err)));
      removeTree(tempZip);
    }
  }
  removeTree(tempZip);

  if (!result) {
    throw new Error(
      (targetDlcId ? "Não foi encontrada uma DLC válida em nenhuma API." : "Não foi encontrado um jogo válido em nenhuma API.") +
      (errors.length ? " " + errors.join(" | ") : "")
    );
  }
  writeResult({ success: true, data: result, error: "" });
}

main().catch((e) => {
  try {
    writeResult({ success: false, error: e && e.message ? e.message : String(e) });
  } catch (_) {}
});
