#!/usr/bin/env node
"use strict";
const fs = require("fs");
const path = require("path");

function arg(i) { return process.argv.length > i + 2 ? String(process.argv[i + 2]) : ""; }
function ensureDir(p) { if (p) fs.mkdirSync(p, { recursive: true }); }
function writeText(p, text) { ensureDir(path.dirname(p)); fs.writeFileSync(p, String(text || ""), "utf8"); }

function acfValue(text, key) {
  const re = new RegExp('"' + key + '"\\s+"([^"]*)"', "i");
  const m = String(text || "").match(re);
  return m ? m[1].replace(/\\\\/g, "\\") : "";
}

function scanSteamApps(steamapps, map) {
  if (!steamapps || !fs.existsSync(steamapps)) return;
  let entries;
  try { entries = fs.readdirSync(steamapps); } catch (_) { return; }
  const common = path.join(steamapps, "common");
  for (const fileName of entries) {
    const match = /^appmanifest_(\d+)\.acf$/i.exec(fileName);
    if (!match) continue;
    const appid = match[1];
    if (map[appid]) continue;
    try {
      const fullPath = path.join(steamapps, fileName);
      const text = fs.readFileSync(fullPath, "utf8");
      const manifestAppid = acfValue(text, "appid") || appid;
      const installdir = acfValue(text, "installdir");
      if (!manifestAppid || !installdir) continue;
      const gamePath = path.join(common, installdir);
      if (!fs.existsSync(gamePath)) continue;
      const name = acfValue(text, "name") || ("AppID " + manifestAppid);
      map[String(manifestAppid)] = {
        appId: Number(manifestAppid),
        appid: Number(manifestAppid),
        gameName: name,
        name,
        fileName,
        fullPath,
        manifestPath: fullPath,
        gamePath,
        installPath: gamePath,
        isDisabled: false,
        isSteamInstalled: true,
        imageUrl: "https://cdn.akamai.steamstatic.com/steam/apps/" + manifestAppid + "/header.jpg"
      };
    } catch (_) {}
  }
}

try {
  const resultPath = arg(0);
  if (!resultPath) throw new Error("Caminho de resultado ausente.");
  const map = {};
  for (let i = 1; i < process.argv.length - 2; i++) scanSteamApps(arg(i), map);
  const items = Object.keys(map)
    .map((k) => map[k])
    .sort((a, b) => String(a.gameName || "").toLowerCase().localeCompare(String(b.gameName || "").toLowerCase()));
  writeText(resultPath, JSON.stringify({ success: true, data: items, error: "" }));
} catch (e) {
  writeText(arg(0), JSON.stringify({ success: false, error: e && e.message ? e.message : String(e) }));
}
