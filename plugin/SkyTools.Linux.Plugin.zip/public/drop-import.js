(function () {
  'use strict';
  function normalizeSteamLink(value) {
    try {
      var url = new URL(String(value || '').trim(), document.baseURI);
      return /^https?:$/.test(url.protocol) && url.hostname === 'store.steampowered.com' && /^\/app\/\d+(\/|$)/.test(url.pathname) ? url.href : '';
    } catch (_) { return ''; }
  }
  function steamLink(dt, fallback) {
    var sourceLink = normalizeSteamLink(fallback);
    if (sourceLink) return sourceLink;
    var texts = ['text/uri-list', 'text/plain', 'text/x-moz-url'].map(function (type) { return dt.getData(type); });
    var html = dt.getData('text/html');
    if (html) texts.push.apply(texts, Array.from(new DOMParser().parseFromString(html, 'text/html').querySelectorAll('a[href]')).map(function (a) { return a.getAttribute('href'); }));
    for (var text of texts) for (var line of text.split(/\r?\n/)) {
      var normalized = normalizeSteamLink(line);
      if (normalized) return normalized;
    }
    return '';
  }
  function steamLinkFromSource(event) {
    var path = typeof event.composedPath === 'function' ? event.composedPath() : [event.target];
    for (var node of path) {
      if (!(node instanceof Element)) continue;
      var link = node.matches('a[href]') ? node : node.closest('a[href]');
      var normalized = link ? normalizeSteamLink(link.getAttribute('href')) : '';
      if (normalized) return normalized;
      var appNode = node.matches('[data-ds-appid],[data-appid],[data-app-id]')
        ? node : node.closest('[data-ds-appid],[data-appid],[data-app-id]');
      if (appNode) {
        var appId = appNode.getAttribute('data-ds-appid') || appNode.getAttribute('data-appid') || appNode.getAttribute('data-app-id') || '';
        appId = String(appId).match(/\d+/)?.[0] || '';
        if (appId) return 'https://store.steampowered.com/app/' + appId + '/';
      }
    }
    return '';
  }
  function attach(root, options) {
    var busy = false, capturedLink = '';
    var overlay = document.createElement('div');
    overlay.className = 'dolin-drop-overlay';
    overlay.textContent = 'Solte arquivos .lua, .manifest, .zip, .rar ou um link da loja Steam para adicionar';
    overlay.style.cssText = 'display:none;position:fixed;inset:12px;z-index:2147483646;pointer-events:none;border:3px dashed var(--accent-light,var(--skytools-accent,#80ccff));border-radius:18px;background:color-mix(in srgb,var(--surface-glass,var(--skytools-bg-elevated,#121c2b)) 94%,transparent);color:var(--text,var(--skytools-text,#fff));box-shadow:0 0 30px var(--accent-shadow,rgba(var(--skytools-accent-rgb,128,204,255),.3));backdrop-filter:blur(18px);font:600 20px system-ui;align-items:center;justify-content:center;text-align:center;padding:32px';
    var overlayHost = root === document ? document.querySelector('.app-shell') || document.body : root;
    overlayHost.appendChild(overlay);
    function eligible(e) { return (!options.accept || options.accept(e)) && e.dataTransfer && (capturedLink || Array.from(e.dataTransfer.types).some(function (t) { return ['Files', 'text/uri-list', 'text/plain', 'text/x-moz-url', 'text/html'].includes(t); })); }
    function capture(e) { capturedLink = options.captureSourceLinks ? steamLinkFromSource(e) : ''; }
    function dragState(active, event) { if (options.dragState) options.dragState(active, event || null); }
    function show(event) {
      if (busy) return;
      if (options.overlayTarget) {
        var target = options.overlayTarget(event);
        if (!target) { overlay.style.display = 'none'; return; }
        if (overlay.parentElement !== target) target.appendChild(overlay);
        overlay.style.position = 'absolute'; overlay.style.inset = '0';
        overlay.style.borderRadius = 'inherit';
      }
      overlay.style.display = 'flex';
    }
    function hide() { overlay.style.display = 'none'; dragState(false); }
    function enter(e) { if (!eligible(e)) return; e.preventDefault(); dragState(true, e); show(e); }
    function over(e) { if (!eligible(e)) { hide(); return; } e.preventDefault(); dragState(true, e); show(e); e.dataTransfer.dropEffect = busy ? 'none' : 'copy'; }
    function leave(e) {
      // Crossing children inside the open panel emits dragleave repeatedly.
      // The next dragover hides the overlay if the pointer really left the target.
      if (!e.relatedTarget || !document.documentElement.contains(e.relatedTarget)) hide();
    }
    async function drop(e) {
      if (!eligible(e)) return;
      e.preventDefault(); e.stopPropagation(); hide();
      if (busy || (options.busy && options.busy())) { options.report('Aguarde a operação atual terminar.', true); return; }
      var files = Array.from(e.dataTransfer.files), link = files.length ? '' : steamLink(e.dataTransfer, capturedLink);
      busy = true;
      options.start();
      var messages = [], errors = [], batchIds = [];
      try {
        if (!files.length && !link) throw new Error('Solte um arquivo .lua, .manifest, .zip, .rar ou um link de jogo/DLC da loja Steam.');
        if (files.length) {
          for (var file of files) {
            var id = null;
            try {
              if (!/\.(lua|manifest|zip|rar)$/i.test(file.name)) throw new Error('Formato não suportado. Use .lua, .manifest, .zip ou .rar.');
              if (file.size > 2 * 1024 * 1024 * 1024) throw new Error('O limite por arquivo é 2 GB.');
              id = await options.invoke('Begin', { name: file.name, size: file.size });
              for (var offset = 0; offset < file.size; offset += 256 * 1024) {
                var bytes = new Uint8Array(await file.slice(offset, offset + 256 * 1024).arrayBuffer());
                var binary = ''; for (var i = 0; i < bytes.length; i += 8192) binary += String.fromCharCode.apply(null, bytes.subarray(i, i + 8192));
                await options.invoke('Chunk', { id: id, offset: offset, data: btoa(binary) });
              }
              batchIds.push(id); id = null;
            } catch (error) { errors.push(file.name + ': ' + (error.message || String(error))); }
            finally { if (id) { try { await options.invoke('Cancel', { id: id }); } catch (_) {} } }
          }
          if (batchIds.length) {
            try {
              messages.push(await options.invoke('CommitBatch', { ids: batchIds }));
              batchIds = [];
            } catch (error) {
              errors.push(error.message || String(error));
            }
          }
        } else messages.push(await options.invoke('Link', { url: link }));
      } catch (error) { errors.push(error.message || String(error)); }
      finally {
        for (var pendingId of batchIds) { try { await options.invoke('Cancel', { id: pendingId }); } catch (_) {} }
        capturedLink = ''; busy = false; options.finish(); options.report(messages.concat(errors).join('\n'), errors.length > 0);
      }
    }
    function end() { capturedLink = ''; hide(); }
    root.addEventListener('dragstart', capture, true);
    root.addEventListener('dragenter', enter, true); root.addEventListener('dragover', over, true);
    root.addEventListener('dragleave', leave, true); root.addEventListener('drop', drop, true);
    window.addEventListener('dragend', end);
    return function () {
      hide();
      root.removeEventListener('dragstart', capture, true);
      root.removeEventListener('dragenter', enter, true); root.removeEventListener('dragover', over, true);
      root.removeEventListener('dragleave', leave, true); root.removeEventListener('drop', drop, true);
      window.removeEventListener('dragend', end); overlay.remove();
    };
  }
  window.DolinDropImport = {
    translateManifestWarning: function (text, lang) {
      var match = String(text).match(/^DLC removida do Lua: (.+)\. Motivo: (.+)\.$/);
      if (!match || !['en', 'es', 'ru'].includes(lang)) return text;
      var index = ['en', 'es', 'ru'].indexOf(lang);
      var terms = {
        'a verificação de integridade (CRC) falhou': ['integrity check (CRC) failed', 'falló la verificación de integridad (CRC)', 'проверка целостности (CRC) не пройдена'],
        'manifest truncado ou sem marcador de término': ['manifest is truncated or missing its end marker', 'manifest truncado o sin marcador final', 'manifest обрезан или не имеет конечного маркера'],
        'nenhum manifest válido foi encontrado nas APIs': ['no valid manifest was found in the APIs', 'no se encontró un manifest válido en las APIs', 'в API не найден допустимый manifest'],
        'nenhum manifest válido foi fornecido para este depot': ['no valid manifest was provided for this depot', 'no se proporcionó un manifest válido para este depot', 'для этого depot не предоставлен допустимый manifest'],
        'os IDs internos não correspondem ao nome do manifest': ['internal IDs do not match the manifest filename', 'los IDs internos no coinciden con el nombre del manifest', 'внутренние ID не соответствуют имени manifest'],
        'a chave do depot não permite ler os nomes dos arquivos': ['the depot key cannot read the file names', 'la clave del depot no permite leer los nombres de los archivos', 'ключ depot не позволяет прочитать имена файлов'],
        'o manifest referenciado pelo Lua está ausente ou inválido': ['the manifest referenced by Lua is missing or invalid', 'el manifest indicado en el Lua falta o no es válido', 'указанный в Lua manifest отсутствует или недопустим'],
        'arquivo corrompido ou chave do depot inválida': ['corrupted file or invalid depot key', 'archivo dañado o clave del depot inválida', 'файл повреждён или ключ depot недопустим'],
        'manifest corrompido ou chave inválida': ['corrupted manifest or invalid key', 'manifest dañado o clave inválida', 'manifest повреждён или ключ недопустим']
      };
      var reason = match[2].split('; ').map(function (part) {
        var split = part.indexOf(': '), prefix = split >= 0 ? part.slice(0, split + 2) : '';
        var detail = split >= 0 ? part.slice(split + 2) : part;
        return prefix + (terms[detail]?.[index] || ['invalid manifest (' + detail + ')', 'manifest inválido (' + detail + ')', 'недопустимый manifest (' + detail + ')'][index]);
      }).join('; ');
      return ['DLC removed from Lua: ', 'DLC eliminado del Lua: ', 'DLC удалено из Lua: '][index] + match[1]
        + ['. Reason: ', '. Motivo: ', '. Причина: '][index] + reason + '.';
    },
    attach: attach,
    attachApp: function (dotnet) {
      if (window.__dolinAppDropCleanup) window.__dolinAppDropCleanup();
      window.__dolinAppDropCleanup = attach(document, {
        invoke: async function (method, payload) {
          var result = await dotnet.invokeMethodAsync('Import', method, payload);
          if (!result.success) throw new Error(result.error);
          return result.data;
        },
        start: function () { dotnet.invokeMethodAsync('Status', 'Adicionando arquivos ou consultando a Steam…', true, false); },
        finish: function () {},
        report: function (message, error) { dotnet.invokeMethodAsync('Status', message, false, !!error); }
      });
    },
    detachApp: function () { if (window.__dolinAppDropCleanup) window.__dolinAppDropCleanup(); delete window.__dolinAppDropCleanup; }
  };
})();
