// SkyTools Millennium local drop importer. Windows Script Host / JScript compatible.
(function () {
  "use strict";
  var fso = new ActiveXObject("Scripting.FileSystemObject");
  var shell = new ActiveXObject("WScript.Shell");
  var args = WScript.Arguments;
  var dataRoot = String(args.Item(0) || "");
  var steamPath = String(args.Item(1) || "");
  var scriptDir = String(args.Item(2) || "");
  var requestPath = String(args.Item(3) || "");
  var resultPath = String(args.Item(4) || "");
  var maxExpanded = 2 * 1024 * 1024 * 1024;
  var maxFiles = 32768;

  function combine(a, b) { return /[\\\/]$/.test(a) ? a + b : a + "\\" + b; }
  function ensureDir(path) {
    if (!path || fso.FolderExists(path)) return;
    var parent = fso.GetParentFolderName(path);
    if (parent && !fso.FolderExists(parent)) ensureDir(parent);
    fso.CreateFolder(path);
  }
  function readText(path) {
    var stream = new ActiveXObject("ADODB.Stream");
    stream.Type = 2; stream.Charset = "utf-8"; stream.Open(); stream.LoadFromFile(path);
    var text = stream.ReadText(); stream.Close();
    return String(text).replace(/^\uFEFF/, "");
  }
  function writeText(path, text) {
    ensureDir(fso.GetParentFolderName(path));
    var stream = new ActiveXObject("ADODB.Stream");
    stream.Type = 2; stream.Charset = "utf-8"; stream.Open(); stream.WriteText(String(text));
    stream.Position = 3; var binary = new ActiveXObject("ADODB.Stream");
    binary.Type = 1; binary.Open(); stream.CopyTo(binary); binary.SaveToFile(path, 2);
    binary.Close(); stream.Close();
  }
  function json(value) {
    if (value === null) return "null";
    if (typeof value === "boolean" || typeof value === "number") return String(value);
    if (typeof value === "string") return '"' + value.replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\r/g, "\\r").replace(/\n/g, "\\n") + '"';
    if (Object.prototype.toString.call(value) === "[object Array]") {
      var items = []; for (var i = 0; i < value.length; i++) items.push(json(value[i])); return "[" + items.join(",") + "]";
    }
    var fields = []; for (var key in value) if (Object.prototype.hasOwnProperty.call(value, key)) fields.push(json(key) + ":" + json(value[key]));
    return "{" + fields.join(",") + "}";
  }
  function writeResult(value) { writeText(resultPath, json(value)); }
  function parseJson(text) { return (new Function("return (" + text + ");"))(); }
  function readJson(path, fallback) { try { return fso.FileExists(path) ? parseJson(readText(path)) : fallback; } catch (_) { return fallback; } }
  function isoNow() {
    var date = new Date(); function pad(value) { return value < 10 ? "0" + value : String(value); }
    return date.getUTCFullYear() + "-" + pad(date.getUTCMonth() + 1) + "-" + pad(date.getUTCDate()) + "T"
      + pad(date.getUTCHours()) + ":" + pad(date.getUTCMinutes()) + ":" + pad(date.getUTCSeconds()) + "Z";
  }
  function quote(value) { return '"' + String(value).replace(/"/g, '\\"') + '"'; }
  function removeTree(path) { try { if (fso.FolderExists(path)) fso.DeleteFolder(path, true); } catch (_) {} }
  function hasParentSegment(path) {
    var parts = String(path || "").split("/");
    for (var i = 0; i < parts.length; i++) if (parts[i] === "..") return true;
    return false;
  }
  function collect(path, result) {
    var folder = fso.GetFolder(path), files = new Enumerator(folder.Files), dirs;
    for (; !files.atEnd(); files.moveNext()) {
      if (result.length >= maxFiles) throw new Error("O pacote excede o limite de " + maxFiles + " arquivos.");
      result.push(String(files.item().Path));
    }
    dirs = new Enumerator(folder.SubFolders); for (; !dirs.atEnd(); dirs.moveNext()) collect(String(dirs.item().Path), result);
  }
  function extract(archive, destination) {
    ensureDir(destination);
    var listing = shell.Exec("tar.exe -tf " + quote(archive)), names = [], output = listing.StdOut.ReadAll();
    if (listing.ExitCode !== 0) throw new Error("N\u00E3o foi poss\u00EDvel examinar " + fso.GetFileName(archive) + ".");
    names = String(output || "").split(/\r?\n/);
    var fileCount = 0;
    for (var index = 0; index < names.length; index++) {
      var name = String(names[index] || "").replace(/\\/g, "/");
      if (!name) continue;
      if (name.charAt(0) === "/" || /^[A-Za-z]:/.test(name) || hasParentSegment(name))
        throw new Error("O pacote cont\u00E9m um caminho inseguro.");
      if (!/\/$/.test(name) && ++fileCount > maxFiles)
        throw new Error("O pacote excede o limite de " + maxFiles + " arquivos.");
    }
    var command = "tar.exe -xf " + quote(archive) + " -C " + quote(destination);
    if (shell.Run(command, 0, true) !== 0) throw new Error("N\u00E3o foi poss\u00EDvel extrair " + fso.GetFileName(archive) + ".");
  }
  function u32(bytes, offset) {
    return (bytes[offset] | (bytes[offset + 1] << 8) | (bytes[offset + 2] << 16) | (bytes[offset + 3] << 24)) >>> 0;
  }
  function varint(bytes, state) {
    var value = 0, multiplier = 1, count = 0, next;
    do {
      if (state.offset >= bytes.length || count++ >= 10) throw new Error("metadados protobuf inv\u00E1lidos");
      next = bytes[state.offset++]; value += (next & 127) * multiplier; multiplier *= 128;
    } while (next & 128);
    return value;
  }
  function decimalTimes(text, multiplier) {
    var carry = 0, result = "";
    for (var i = text.length - 1; i >= 0; i--) {
      var value = Number(text.charAt(i)) * multiplier + carry;
      result = String(value % 10) + result; carry = Math.floor(value / 10);
    }
    while (carry) { result = String(carry % 10) + result; carry = Math.floor(carry / 10); }
    return result.replace(/^0+(?=\d)/, "");
  }
  function decimalPlus(text, addition) {
    var carry = addition, index = text.length - 1, result = "";
    while (index >= 0 || carry) {
      var value = (index >= 0 ? Number(text.charAt(index--)) : 0) + carry;
      result = String(value % 10) + result; carry = Math.floor(value / 10);
    }
    return (index >= 0 ? text.substring(0, index + 1) : "") + result;
  }
  function varintDecimal(bytes, state) {
    var parts = [], count = 0, next;
    do {
      if (state.offset >= bytes.length || count++ >= 10) throw new Error("metadados protobuf inv\u00E1lidos");
      next = bytes[state.offset++]; parts.push(next & 127);
    } while (next & 128);
    var value = "0";
    for (var i = parts.length - 1; i >= 0; i--) value = decimalPlus(decimalTimes(value, 128), parts[i]);
    return value;
  }
  function metadataFields(bytes) {
    var state = { offset: 0 }, result = {};
    while (state.offset < bytes.length) {
      var tag = varint(bytes, state), field = Math.floor(tag / 8), wire = tag % 8, value;
      if (wire === 0) value = field === 2 ? varintDecimal(bytes, state) : varint(bytes, state);
      else if (wire === 1) { state.offset += 8; continue; }
      else if (wire === 2) { state.offset += varint(bytes, state); continue; }
      else if (wire === 5) { state.offset += 4; continue; }
      else throw new Error("metadados protobuf inv\u00E1lidos");
      if (field === 1 || field === 2 || field === 4 || field === 8 || field === 9) result[field] = value;
      if (state.offset > bytes.length) throw new Error("metadados protobuf truncados");
    }
    return result;
  }
  function crc32(bytes, start, length) {
    var table = [], i, j, value;
    for (i = 0; i < 256; i++) { value = i; for (j = 0; j < 8; j++) value = (value & 1) ? (0xEDB88320 ^ (value >>> 1)) : (value >>> 1); table[i] = value; }
    var crc = 0xFFFFFFFF;
    for (i = start; i < start + length; i++) crc = table[(crc ^ bytes[i]) & 255] ^ (crc >>> 8);
    return (crc ^ 0xFFFFFFFF) >>> 0;
  }
  function validateManifest(path) {
    var name = fso.GetFileName(path), match = /^(\d+)_(\d+)\.manifest$/i.exec(name);
    if (!match || match[1] === "0" || match[2] === "0") throw new Error(name + ": nome inv\u00E1lido; esperado DepotID_ManifestID.manifest.");
    var size = Number(fso.GetFile(path).Size);
    if (size <= 16 || size > 128 * 1024 * 1024) throw new Error(name + ": arquivo vazio ou acima do limite.");
    var stream = new ActiveXObject("ADODB.Stream"); stream.Type = 1; stream.Open(); stream.LoadFromFile(path);
    var bytes = new VBArray(stream.Read()).toArray(); stream.Close();
    var offset = 0, payloadStart = -1, payloadLength = 0, metadata = null, signature = false, ended = false;
    while (offset + 4 <= bytes.length) {
      var magic = u32(bytes, offset); offset += 4;
      if (magic === 0x32C415AB) { ended = offset === bytes.length && payloadStart >= 0 && metadata && signature; break; }
      if (offset + 4 > bytes.length) break;
      var length = u32(bytes, offset); offset += 4;
      if (length > bytes.length - offset) break;
      if (magic === 0x71F617D0 && payloadStart < 0) { payloadStart = offset - 4; payloadLength = length + 4; }
      else if (magic === 0x1F4812BE && !metadata) metadata = metadataFields(bytes.slice(offset, offset + length));
      else if (magic === 0x1B81B817 && !signature) signature = true;
      else throw new Error(name + ": formato de manifest inv\u00E1lido.");
      offset += length;
    }
    if (!ended) throw new Error(name + ": manifest truncado ou sem marcador de t\u00E9rmino.");
    if (Number(metadata[1] || 0) !== Number(match[1]) || String(metadata[2] || "") !== String(match[2]))
      throw new Error(name + ": os IDs internos n\u00E3o correspondem ao nome do manifest.");
    var expectedCrc = Number(metadata[metadata[4] ? 8 : 9]);
    if (isNaN(expectedCrc) || crc32(bytes, payloadStart, payloadLength) !== (expectedCrc >>> 0))
      throw new Error(name + ": a verifica\u00E7\u00E3o de integridade (CRC) falhou.");
    return { depotId: match[1], manifestId: match[2] };
  }
  function appIdFromLua(path, text) {
    var file = /^(\d+)\.lua$/i.exec(fso.GetFileName(path));
    var entries = luaEntries(text);
    if (file) return entries[file[1]] ? file[1] : "";
    var call = /(?:^|[\r\n])\s*addappid\s*\(\s*(\d+)/i.exec(text);
    return call ? call[1] : "";
  }
  function countDlcs(text, appid, knownDlcIds) {
    var seen = {}, count = 0, regex = /(?:^|[\r\n])\s*addappid\s*\(\s*(\d+)/ig, match;
    while ((match = regex.exec(text))) if (match[1] !== appid && (!knownDlcIds || knownDlcIds[match[1]]) && !seen[match[1]]) { seen[match[1]] = true; count++; }
    return count;
  }

  function httpJson(url) {
    var http = new ActiveXObject("MSXML2.ServerXMLHTTP.6.0");
    http.setTimeouts(5000, 5000, 12000, 18000);
    http.open("GET", url, false);
    http.setRequestHeader("User-Agent", "SkyToolsPlugin/1.5.1");
    http.setRequestHeader("Accept", "application/json,*/*");
    http.send();
    if (http.status < 200 || http.status >= 300) throw new Error("HTTP " + http.status);
    return parseJson(String(http.responseText || "{}"));
  }

  function steamDepotMap(appid, lua) {
    var response;
    try { response = httpJson("https://api.steamcmd.net/v1/info/" + encodeURIComponent(appid)); }
    catch (_) { throw new Error("N\u00E3o foi poss\u00EDvel confirmar os depots do jogo na SteamCMD. Tente novamente."); }
    var app = response && response.data ? (response.data[String(appid)] || response.data[Number(appid)]) : null;
    if (!app || typeof app !== "object")
      throw new Error("N\u00E3o foi poss\u00EDvel confirmar os depots do jogo na SteamCMD. Tente novamente.");
    var map = { base: {}, optional: {}, shared: {}, dlcByDepot: {}, dlcIds: {}, all: {} }, depots = app.depots || {};
    var listedDlcs = String(app.extended && app.extended.listofdlc || "").split(",");
    for (var listedIndex = 0; listedIndex < listedDlcs.length; listedIndex++)
      if (/^\d+$/.test(String(listedDlcs[listedIndex]).replace(/\s/g, "")))
        map.dlcIds[String(listedDlcs[listedIndex]).replace(/\s/g, "")] = true;
    for (var id in depots) if (Object.prototype.hasOwnProperty.call(depots, id) && /^\d+$/.test(id)) {
      var depot = depots[id] || {}, config = depot.config || {};
      var isShared = id === "228989" || id === "228990"
        || (depot.depotfromapp && String(depot.depotfromapp) !== String(appid))
        || depot.sharedinstall === true || String(depot.sharedinstall || "").toLowerCase() === "1"
        || String(depot.sharedinstall || "").toLowerCase() === "true";
      var dlcId = depot.dlcappid ? String(depot.dlcappid) : "", hasManifest = false;
      if (Object.prototype.hasOwnProperty.call(depot, "manifests") && depot.manifests && typeof depot.manifests === "object")
        for (var branch in depot.manifests) if (Object.prototype.hasOwnProperty.call(depot.manifests, branch)) { hasManifest = true; break; }
      var emptyDepot = Object.prototype.hasOwnProperty.call(depot, "manifests") && !hasManifest;
      var osList = String(config.oslist || "").toLowerCase().replace(/\s/g, "");
      var otherPlatform = osList && ("," + osList + ",").indexOf(",windows,") < 0;
      map.all[id] = true;
      if (dlcId) { map.dlcByDepot[id] = dlcId; map.dlcIds[dlcId] = true; }
      if (isShared) map.shared[id] = true;
      else if (config.language || otherPlatform || emptyDepot) map.optional[id] = true;
      else if (!dlcId) map.base[id] = true;
    }
    var lines = String(lua || "").replace(/--\[(=*)\[[\s\S]*?\]\1\]/g, "").split(/\r\n|\n|\r/), inspected = 0;
    for (var lineIndex = 0; lineIndex < lines.length && inspected < 64; lineIndex++) {
      var candidateMatch = lines[lineIndex].match(/^\s*addappid\s*\(\s*(\d+)/i);
      if (!candidateMatch || candidateMatch[1] === String(appid) || map.all[candidateMatch[1]]
          || !/--.*\b(?:dlc|soundtrack|music)\b/i.test(lines[lineIndex])) continue;
      inspected++;
      var candidate = candidateMatch[1];
      try {
        var store = httpJson("https://store.steampowered.com/api/appdetails?appids=" + encodeURIComponent(candidate));
        var detail = store && store[candidate] && store[candidate].success ? store[candidate].data : null;
        if (!detail || !detail.fullgame || String(detail.fullgame.appid) !== String(appid)) continue;
        var related = httpJson("https://api.steamcmd.net/v1/info/" + encodeURIComponent(candidate));
        var relatedApp = related && related.data ? (related.data[candidate] || related.data[Number(candidate)]) : null;
        var relatedDepots = relatedApp && relatedApp.depots ? relatedApp.depots : {};
        for (var relatedId in relatedDepots) if (Object.prototype.hasOwnProperty.call(relatedDepots, relatedId) && /^\d+$/.test(relatedId)) {
          var relatedDepot = relatedDepots[relatedId] || {}, relatedConfig = relatedDepot.config || {}, relatedHasManifest = false;
          if (Object.prototype.hasOwnProperty.call(relatedDepot, "manifests") && relatedDepot.manifests && typeof relatedDepot.manifests === "object")
            for (var relatedBranch in relatedDepot.manifests) if (Object.prototype.hasOwnProperty.call(relatedDepot.manifests, relatedBranch)) { relatedHasManifest = true; break; }
          var relatedOs = String(relatedConfig.oslist || "").toLowerCase().replace(/\s/g, "");
          map.all[relatedId] = true;
          map.dlcByDepot[relatedId] = candidate;
          map.dlcIds[candidate] = true;
          if ((Object.prototype.hasOwnProperty.call(relatedDepot, "manifests") && !relatedHasManifest)
              || (relatedOs && ("," + relatedOs + ",").indexOf(",windows,") < 0)
              || relatedConfig.language) map.optional[relatedId] = true;
        }
      } catch (_) {}
    }
    for (var canonical in map.dlcByDepot) if (Object.prototype.hasOwnProperty.call(map.dlcByDepot, canonical)
        && canonical === map.dlcByDepot[canonical] && !map.optional[canonical] && !map.shared[canonical]) {
      for (var alias in map.dlcByDepot) if (Object.prototype.hasOwnProperty.call(map.dlcByDepot, alias)
          && alias !== canonical && map.dlcByDepot[alias] === canonical) map.optional[alias] = true;
    }
    return map;
  }

  function luaEntries(text) {
    var entries = {}, lines = String(text || "").replace(/--\[(=*)\[[\s\S]*?\]\1\]/g, "").split(/\r\n|\n|\r/);
    for (var i = 0; i < lines.length; i++) {
      var match = lines[i].match(/^\s*addappid\s*\(\s*(\d+)/i);
      if (match) entries[match[1]] = true;
    }
    return entries;
  }

  function removeLuaEntries(text, ids) {
    var lines = String(text || "").split(/\r\n|\n|\r/), kept = [];
    for (var i = 0; i < lines.length; i++) {
      var match = lines[i].match(/^\s*addappid\s*\(\s*(\d+)/i);
      if (!match || !ids[match[1]]) kept.push(lines[i]);
    }
    return kept.join("\r\n");
  }

  function ensureManifestLocks(text, identities) {
    var newline = String(text).indexOf("\r\n") >= 0 ? "\r\n" : "\n";
    var trailing = /[\r\n]$/.test(String(text)), lines = String(text || "").split(/\r\n|\n|\r/);
    for (var i = 0; i < identities.length; i++) {
      var wanted = identities[i], found = false;
      for (var lineIndex = 0; lineIndex < lines.length; lineIndex++) {
        var match = lines[lineIndex].match(/^(\s*)(--\s*)?(setmanifestid\s*\(\s*(\d+)\s*,\s*["']?(\d+)["']?\s*\))(\s*(?:--.*)?)$/i);
        if (!match || match[4] !== String(wanted.depotId) || match[5] !== String(wanted.manifestId)) continue;
        found = true;
        if (match[2]) lines[lineIndex] = match[1] + match[3] + match[6];
        break;
      }
      if (!found) lines.push("setManifestid(" + wanted.depotId + ",\"" + wanted.manifestId + "\")");
    }
    return lines.join(newline).replace(/[\r\n]+$/, "") + (trailing || lines.length ? newline : "");
  }

  function steamName(appid) {
    try {
      var response = httpJson("https://store.steampowered.com/api/appdetails?appids=" + encodeURIComponent(appid));
      var item = response ? response[String(appid)] : null;
      return item && item.success && item.data && item.data.name ? String(item.data.name) : "AppID " + appid;
    } catch (_) { return "AppID " + appid; }
  }

  function filterGamePackage(appid, lua, manifestPaths) {
    var map = steamDepotMap(appid, lua), valid = [], validByPair = {}, validByDepot = {}, broken = {}, seen = {};
    for (var i = 0; i < manifestPaths.length; i++) {
      var fileName = String(fso.GetFileName(manifestPaths[i])).toLowerCase();
      if (seen[fileName]) throw new Error("A sele\u00E7\u00E3o cont\u00E9m nomes de manifest repetidos.");
      seen[fileName] = true;
      var nameMatch = /^(\d+)_(\d+)\.manifest$/i.exec(fileName), depot = nameMatch ? nameMatch[1] : "";
      if (depot && depot === String(appid)) { map.base[depot] = true; map.all[depot] = true; }
      if (!depot || !map.all[depot]) throw new Error("O pacote cont\u00E9m um depot que n\u00E3o pertence ao jogo: " + (depot || fileName) + ".");
      try {
        var identity = validateManifest(manifestPaths[i]);
        valid.push({ path: manifestPaths[i], depotId: identity.depotId, manifestId: identity.manifestId });
        validByPair[identity.depotId + "_" + identity.manifestId] = true;
        validByDepot[identity.depotId] = true;
      } catch (error) { broken[depot] = error.message || String(error); }
    }
    var entries = luaEntries(lua), reference = /(?:^|[\r\n])\s*setmanifestid\s*\(\s*(\d+)\s*,\s*["']?(\d+)/ig, match;
    while ((match = reference.exec(lua))) {
      if (map.all[match[1]] && !map.shared[match[1]] && !map.optional[match[1]]
          && !validByPair[match[1] + "_" + match[2]])
        broken[match[1]] = "o manifest referenciado pelo Lua est\u00E1 ausente ou inv\u00E1lido";
    }
    for (var baseId in map.base) if (Object.prototype.hasOwnProperty.call(map.base, baseId)
        && entries[baseId] && !validByDepot[baseId])
      broken[baseId] = broken[baseId] || "nenhum manifest v\u00E1lido foi fornecido para este depot";
    for (var dlcDepot in map.dlcByDepot) if (Object.prototype.hasOwnProperty.call(map.dlcByDepot, dlcDepot)) {
      var dlcAppId = map.dlcByDepot[dlcDepot];
      if (entries[dlcAppId] && !map.shared[dlcDepot] && !map.optional[dlcDepot] && !validByDepot[dlcDepot])
        broken[dlcDepot] = broken[dlcDepot] || "nenhum manifest v\u00E1lido foi fornecido para este depot";
    }
    var primary = [], baseBroken = false;
    for (baseId in map.base) if (Object.prototype.hasOwnProperty.call(map.base, baseId) && !map.shared[baseId]) primary.push(baseId);
    if (!primary.length) for (var optionalId in map.optional)
      if (Object.prototype.hasOwnProperty.call(map.optional, optionalId) && !map.shared[optionalId]) primary.push(optionalId);
    for (i = 0; i < primary.length; i++) if (map.base[primary[i]] && broken[primary[i]]) baseBroken = true;
    var hasPrimary = false;
    for (i = 0; i < primary.length; i++) if (validByDepot[primary[i]]) { hasPrimary = true; break; }
    if (baseBroken || !hasPrimary) {
      var details = [];
      for (i = 0; i < primary.length; i++) if (broken[primary[i]]) details.push("Depot " + primary[i] + ": " + broken[primary[i]]);
      throw new Error("O manifest do jogo principal est\u00E1 ausente ou inv\u00E1lido." + (details.length ? " " + details.join("; ") : ""));
    }
    var removeIds = {}, removedDepots = {}, warnings = [];
    for (dlcDepot in map.dlcByDepot) if (Object.prototype.hasOwnProperty.call(map.dlcByDepot, dlcDepot) && broken[dlcDepot]) {
      dlcAppId = map.dlcByDepot[dlcDepot];
      removeIds[dlcDepot] = true; removeIds[dlcAppId] = true; removedDepots[dlcDepot] = true;
      warnings.push("DLC removida do Lua: " + steamName(dlcAppId) + " (AppID " + dlcAppId + "). Motivo: depot " + dlcDepot + ": " + broken[dlcDepot] + ".");
    }
    if (warnings.length) lua = removeLuaEntries(lua, removeIds);
    var kept = [], identities = [];
    for (i = 0; i < valid.length; i++) if (!removedDepots[valid[i].depotId] && !broken[valid[i].depotId]) {
      kept.push(valid[i].path); identities.push(valid[i]);
    }
    return { lua: ensureManifestLocks(lua, identities), manifests: kept, warnings: warnings, dlcIds: map.dlcIds };
  }

  var work = combine(combine(dataRoot, "temp"), "drop-import-" + new Date().getTime());
  try {
    if (!requestPath || !fso.FileExists(requestPath)) throw new Error("Solicita\u00E7\u00E3o de importa\u00E7\u00E3o ausente.");
    var request = parseJson(readText(requestPath)), paths = request.files || [], files = [], expanded = 0;
    ensureDir(work);
    for (var i = 0; i < paths.length; i++) {
      var path = String(paths[i] || ""), ext = String(fso.GetExtensionName(path)).toLowerCase();
      if (!fso.FileExists(path)) throw new Error("Arquivo recebido n\u00E3o encontrado.");
      if (ext === "zip" || ext === "rar") {
        var extracted = combine(work, "archive-" + i); extract(path, extracted); collect(extracted, files);
      } else if (ext === "lua" || ext === "manifest") files.push(path);
      else throw new Error("Formato n\u00E3o suportado: " + fso.GetFileName(path));
    }
    if (files.length > maxFiles) throw new Error("O pacote excede o limite de " + maxFiles + " arquivos.");
    var luaFiles = [], manifests = [];
    for (i = 0; i < files.length; i++) {
      expanded += Number(fso.GetFile(files[i]).Size);
      if (expanded > maxExpanded) throw new Error("O pacote excede o limite de 2 GB descompactados.");
      var extension = String(fso.GetExtensionName(files[i])).toLowerCase();
      if (extension === "lua") luaFiles.push(files[i]);
      else if (extension === "manifest") manifests.push(files[i]);
    }
    if (!luaFiles.length && !manifests.length) throw new Error("Nenhum arquivo .lua ou .manifest foi encontrado.");
    if (luaFiles.length > 1) throw new Error("Selecione os arquivos de apenas um jogo por vez.");
    var validManifests = [], seenManifest = {}, warnings = [], games = [], totalDlcs = 0;
    if (luaFiles.length) {
      var lua = readText(luaFiles[0]), appid = appIdFromLua(luaFiles[0], lua);
      if (!appid) throw new Error(fso.GetFileName(luaFiles[0]) + ": n\u00E3o foi poss\u00EDvel identificar o AppID.");
      var filtered = filterGamePackage(appid, lua, manifests);
      lua = filtered.lua; validManifests = filtered.manifests; warnings = filtered.warnings;
      writeText(combine(scriptDir, appid + ".lua"), lua);
      var dlcCount = countDlcs(lua, appid, filtered.dlcIds); totalDlcs += dlcCount;
      games.push({ appId: Number(appid), scriptPath: combine(scriptDir, appid + ".lua"), dlcCount: dlcCount });
    } else {
      for (i = 0; i < manifests.length; i++) {
        var identity = validateManifest(manifests[i]), key = String(fso.GetFileName(manifests[i])).toLowerCase();
        if (seenManifest[key]) throw new Error("A sele\u00E7\u00E3o cont\u00E9m nomes de manifest repetidos.");
        seenManifest[key] = true; validManifests.push(manifests[i]);
      }
    }
    var depotCache = combine(steamPath, "depotcache"), installedFiles = [];
    ensureDir(depotCache); ensureDir(scriptDir);
    var ownerId = games.length === 1 ? games[0].appId : 0;
    var backupDir = ownerId ? combine(combine(combine(dataRoot, "manifest-backups"), String(ownerId)), String(new Date().getTime())) : "";
    for (i = 0; i < validManifests.length; i++) {
      var destination = combine(depotCache, fso.GetFileName(validManifests[i])), previous = "";
      if (fso.FileExists(destination) && backupDir) {
        previous = combine(combine(backupDir, "manifests"), fso.GetFileName(destination));
        ensureDir(fso.GetParentFolderName(previous)); fso.CopyFile(destination, previous, true);
      }
      fso.CopyFile(validManifests[i], destination, true);
      installedFiles.push({ InstalledPath: destination, PreviousBackup: previous });
    }
    if (ownerId) {
      var recordsPath = combine(dataRoot, "manifest-installs.json"), records = readJson(recordsPath, []), kept = [];
      if (Object.prototype.toString.call(records) !== "[object Array]") records = [];
      for (i = 0; i < records.length; i++) if (String((records[i] || {}).AppId || (records[i] || {}).appId || "") !== String(ownerId)) kept.push(records[i]);
      kept.push({ AppId: ownerId, SourceName: "Arraste e solte", InstalledAt: isoNow(),
        ScriptPath: games[0].scriptPath, ManifestFiles: installedFiles });
      writeText(recordsPath, json(kept));
    }
    writeResult({ success: true, data: { games: games, gameCount: games.length, manifestCount: validManifests.length, dlcCount: totalDlcs,
      warnings: warnings, message: (games.length ? (games.length + " jogo(s) adicionado(s). ") : "")
        + validManifests.length + " manifest(s) instalado(s)." + (warnings.length ? " " + warnings.join(" ") : "") }, error: "" });
  } catch (error) {
    writeResult({ success: false, error: error && error.message ? error.message : String(error) });
  } finally { removeTree(work); }
})();
