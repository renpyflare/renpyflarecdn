// SkyTools installed-script scanner for Windows Script Host.
// Original helper: scans Steam script folders and returns JSON to the Lua backend.
(function () {
  var fso = new ActiveXObject("Scripting.FileSystemObject");

  function arg(index) {
    return WScript.Arguments.length > index ? String(WScript.Arguments.Item(index)) : "";
  }

  function ensureDir(path) {
    if (!path || fso.FolderExists(path)) return;
    var parent = fso.GetParentFolderName(path);
    if (parent && !fso.FolderExists(parent)) ensureDir(parent);
    if (!fso.FolderExists(path)) fso.CreateFolder(path);
  }

  function writeText(path, text) {
    ensureDir(fso.GetParentFolderName(path));
    var stream = new ActiveXObject("ADODB.Stream");
    stream.Type = 2;
    stream.Charset = "utf-8";
    stream.Open();
    stream.WriteText(String(text || ""));
    stream.SaveToFile(path, 2);
    stream.Close();
  }

  function jsonEscape(value) {
    return String(value == null ? "" : value)
      .replace(/\\/g, "\\\\")
      .replace(/"/g, "\\\"")
      .replace(/\r/g, "\\r")
      .replace(/\n/g, "\\n")
      .replace(/\t/g, "\\t");
  }

  function itemJson(item) {
    return "{"
      + "\"appId\":" + Number(item.appId) + ","
      + "\"gameName\":\"" + jsonEscape(item.gameName || "") + "\","
      + "\"fileName\":\"" + jsonEscape(item.fileName) + "\","
      + "\"fullPath\":\"" + jsonEscape(item.fullPath) + "\","
      + "\"scriptDirectory\":\"" + jsonEscape(item.scriptDirectory) + "\","
      + "\"dlcCount\":" + Number(item.dlcCount || 0) + ","
      + "\"dlcAppIds\":" + stringArrayJson(item.dlcAppIds || []) + ","
      + "\"dlcs\":" + dlcArrayJson(item.dlcs || []) + ","
      + "\"manifestEntries\":" + manifestArrayJson(item.manifestEntries || []) + ","
      + "\"activeManifestDepotIds\":" + stringArrayJson(item.activeManifestDepotIds || []) + ","
      + "\"luaDepotId\":\"" + jsonEscape(item.luaDepotId || "") + "\","
      + "\"luaManifestId\":\"" + jsonEscape(item.luaManifestId || "") + "\","
      + "\"updatesLocked\":" + (item.updatesLocked ? "true" : "false") + ","
      + "\"isDisabled\":" + (item.isDisabled ? "true" : "false")
      + "}";
  }

  function stringArrayJson(values) {
    var parts = [];
    for (var i = 0; i < values.length; i += 1) {
      parts.push("\"" + jsonEscape(values[i]) + "\"");
    }
    return "[" + parts.join(",") + "]";
  }

  function dlcArrayJson(values) {
    var parts = [];
    for (var i = 0; i < values.length; i += 1) {
      parts.push("{"
        + "\"id\":\"" + jsonEscape(values[i].id || "") + "\","
        + "\"enabled\":" + (values[i].enabled ? "true" : "false") + ","
        + "\"label\":\"" + jsonEscape(values[i].label || "") + "\""
        + "}");
    }
    return "[" + parts.join(",") + "]";
  }

  function manifestArrayJson(values) {
    var parts = [];
    for (var i = 0; i < values.length; i += 1) {
      parts.push("{"
        + "\"depotId\":\"" + jsonEscape(values[i].depotId || "") + "\","
        + "\"manifestId\":\"" + jsonEscape(values[i].manifestId || "") + "\","
        + "\"enabled\":" + (values[i].enabled ? "true" : "false")
        + "}");
    }
    return "[" + parts.join(",") + "]";
  }

  function readTextWithCharset(path, charset) {
    var stream = new ActiveXObject("ADODB.Stream");
    stream.Type = 2;
    stream.Charset = charset;
    stream.Open();
    stream.LoadFromFile(path);
    var text = stream.ReadText();
    stream.Close();
    return text;
  }

  function readText(path) {
    var charsets = ["utf-8", "windows-1252", "unicode"];
    for (var i = 0; i < charsets.length; i += 1) {
      try {
        return readTextWithCharset(path, charsets[i]);
      } catch (_) {
      }
    }
    var file = fso.OpenTextFile(path, 1, false);
    var text = file.ReadAll();
    file.Close();
    return text;
  }

  function stripLuaComments(text) {
    text = String(text || "").replace(/--\[(=*)\[[\s\S]*?\]\1\]/g, "");
    return text.replace(/--[^\r\n]*/g, "");
  }

  function maskLuaBlockComments(text) {
    return String(text || "").replace(/--\[(=*)\[[\s\S]*?\]\1\]/g, function (block) {
      return block.replace(/[^\r\n]/g, " ");
    });
  }

  function cleanGameName(value, appid) {
    var name = String(value || "")
      .replace(/[\x00-\x1f\x7f]/g, " ")
      .replace(/\s+/g, " ")
      .replace(/^\s+|\s+$/g, "");
    if (!name || /^\d+$/.test(name) || name.toLowerCase() === ("appid " + appid).toLowerCase()) return "";
    if (/addappid|setmanifestid|addtoken|main application|provided by|created by|generated (with|by)|fetched from|redistribution|join (the )?(server|discord)|discord\.|lua and manifest|website\s*:|total\s+(depots?|dlcs?)|steam store|^depots?\b|^dlc\b/i.test(name)) return "";
    return name.length > 180 ? name.substring(0, 180) : name;
  }

  function extractGameName(text, appid) {
    var lines = maskLuaBlockComments(text).split(/\r\n|\n|\r/);
    var i;
    var match;
    for (i = 0; i < lines.length; i += 1) {
      match = lines[i].match(/^\s*--\s*(\d+)\s*-\s*(.+?)\s*$/);
      if (match && String(match[1]) === String(appid)) {
        var numbered = cleanGameName(match[2], appid);
        if (numbered) return numbered;
      }
    }
    for (i = 0; i < lines.length; i += 1) {
      match = lines[i].match(/^\s*--\s*Game\s*:\s*(.+?)\s*$/i);
      if (match) {
        var header = cleanGameName(match[1], appid);
        if (header) return header;
      }
    }
    for (i = 0; i < lines.length; i += 1) {
      match = lines[i].match(/^\s*addappid\s*\(\s*(\d+)[^)]*\)\s*--\s*(.+?)\s*$/i);
      if (match && String(match[1]) === String(appid)) {
        var inline = cleanGameName(match[2], appid);
        if (inline) return inline;
      }
    }
    for (i = 0; i < lines.length && i < 30; i += 1) {
      match = lines[i].match(/^\s*--\s+(.+?)\s*$/);
      if (match) {
        var generic = cleanGameName(match[1], appid);
        if (generic) return generic;
      }
    }
    return "";
  }

  function scanLuaState(path, appid) {
    var state = {
      gameName: "",
      dlcCount: 0,
      dlcAppIds: [],
      dlcs: [],
      manifestEntries: [],
      activeManifestDepotIds: [],
      luaDepotId: "",
      luaManifestId: "",
      updatesLocked: false
    };
    try {
      var rawText = readText(path);
      state.gameName = extractGameName(rawText, appid);
      var text = stripLuaComments(rawText);
      var activeDlcRegex = /addappid\s*\(\s*(\d+)/ig;
      var seenActiveDlcs = {};
      var match;
      while ((match = activeDlcRegex.exec(text)) !== null) {
        var id = String(match[1]);
        if (id !== String(appid) && !seenActiveDlcs[id]) {
          seenActiveDlcs[id] = true;
          state.dlcAppIds.push(id);
        }
      }
      state.dlcCount = state.dlcAppIds.length;

      var manifestRegex = /setmanifestid\s*\(\s*(\d+)\s*,\s*["']?(\d+)["']?/ig;
      var seenDepots = {};
      while ((match = manifestRegex.exec(text)) !== null) {
        var depotId = String(match[1]);
        if (!seenDepots[depotId]) {
          seenDepots[depotId] = true;
          state.activeManifestDepotIds.push(depotId);
        }
      }

      var visibleText = maskLuaBlockComments(rawText);
      var lines = visibleText.split(/\r\n|\n|\r/);
      var dlcMap = {};
      var manifests = [];
      for (var lineIndex = 0; lineIndex < lines.length; lineIndex += 1) {
        var line = lines[lineIndex];
        var commentedDlc = line.match(/^\s*--\s*addappid\s*\(\s*(\d+)/i);
        var activeDlc = commentedDlc ? null : line.match(/^\s*addappid\s*\(\s*(\d+)/i);
        var dlcMatch = activeDlc || commentedDlc;
        if (dlcMatch) {
          var dlcId = String(dlcMatch[1]);
          if (dlcId !== String(appid)) {
            var labelMatch = line.match(/\)\s*--\s*(.+)\s*$/);
            var label = labelMatch ? String(labelMatch[1]).replace(/^\s+|\s+$/g, "") : "";
            if (!dlcMap[dlcId]) {
              dlcMap[dlcId] = { id: dlcId, enabled: !!activeDlc, label: label };
              state.dlcs.push(dlcMap[dlcId]);
            } else if (activeDlc) {
              dlcMap[dlcId].enabled = true;
            }
          }
        }

        var commentedManifest = line.match(/^\s*--\s*setmanifestid\s*\(\s*(\d+)\s*,\s*["']?(\d+)["']?/i);
        var activeManifest = commentedManifest ? null : line.match(/^\s*setmanifestid\s*\(\s*(\d+)\s*,\s*["']?(\d+)["']?/i);
        var manifestMatch = activeManifest || commentedManifest;
        if (manifestMatch) {
          manifests.push({
            depotId: String(manifestMatch[1]),
            manifestId: String(manifestMatch[2]),
            enabled: !!activeManifest
          });
        }
      }

      var preferredDepot = String(Number(appid) + 1);
      var selectedManifest = null;
      for (var manifestIndex = 0; manifestIndex < manifests.length; manifestIndex += 1) {
        if (manifests[manifestIndex].depotId === preferredDepot) {
          selectedManifest = manifests[manifestIndex];
          break;
        }
      }
      if (!selectedManifest) {
        for (var fallbackIndex = 0; fallbackIndex < manifests.length; fallbackIndex += 1) {
          if (!dlcMap[manifests[fallbackIndex].depotId]) {
            selectedManifest = manifests[fallbackIndex];
            break;
          }
        }
      }
      if (selectedManifest) {
        state.luaDepotId = selectedManifest.depotId;
        state.luaManifestId = selectedManifest.manifestId;
        state.updatesLocked = selectedManifest.enabled;
      }
      state.manifestEntries = manifests;
    } catch (_) {
    }
    return state;
  }

  function scanDir(directory, map) {
    if (!directory || !fso.FolderExists(directory)) return;
    var folder = fso.GetFolder(directory);
    var files = new Enumerator(folder.Files);
    for (; !files.atEnd(); files.moveNext()) {
      var file = files.item();
      var name = String(file.Name);
      var match = name.match(/^(\d+)\.lua(\.disabled)?$/i);
      if (!match) continue;
      var appid = String(match[1]);
      var luaState = scanLuaState(String(file.Path), appid);
      var item = {
        appId: Number(appid),
        gameName: luaState.gameName,
        fileName: name,
        fullPath: String(file.Path),
        scriptDirectory: directory,
        dlcCount: luaState.dlcCount,
        dlcAppIds: luaState.dlcAppIds,
        dlcs: luaState.dlcs,
        manifestEntries: luaState.manifestEntries,
        activeManifestDepotIds: luaState.activeManifestDepotIds,
        luaDepotId: luaState.luaDepotId,
        luaManifestId: luaState.luaManifestId,
        updatesLocked: luaState.updatesLocked,
        isDisabled: !!match[2]
      };
      if (!map[appid] || !item.isDisabled) {
        map[appid] = item;
      }
    }
  }

  try {
    var resultPath = arg(0);
    if (!resultPath) throw new Error("Caminho de resultado ausente.");
    var map = {};
    for (var i = 1; i < WScript.Arguments.length; i += 1) {
      scanDir(arg(i), map);
    }
    var ids = [];
    for (var id in map) {
      if (Object.prototype.hasOwnProperty.call(map, id)) ids.push(Number(id));
    }
    ids.sort(function (a, b) { return a - b; });
    var items = [];
    for (var j = 0; j < ids.length; j += 1) {
      items.push(itemJson(map[String(ids[j])]));
    }
    writeText(resultPath, "{\"success\":true,\"data\":[" + items.join(",") + "],\"error\":\"\"}");
  } catch (error) {
    writeText(arg(0), "{\"success\":false,\"error\":\"" + jsonEscape(error && error.message ? error.message : String(error)) + "\"}");
  }
})();
