// Resolves a Steam Store game/DLC link for the Millennium backend.
(function () {
  "use strict";
  var args = WScript.Arguments, url = String(args.Item(0) || ""), resultPath = String(args.Item(1) || "");
  var fso = new ActiveXObject("Scripting.FileSystemObject");
  function esc(value) { return String(value || "").replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\r/g, "\\r").replace(/\n/g, "\\n"); }
  function write(value) {
    var stream = new ActiveXObject("ADODB.Stream"); stream.Type = 2; stream.Charset = "utf-8"; stream.Open();
    stream.WriteText(value); stream.Position = 3;
    var binary = new ActiveXObject("ADODB.Stream"); binary.Type = 1; binary.Open(); stream.CopyTo(binary); binary.SaveToFile(resultPath, 2);
    binary.Close(); stream.Close();
  }
  try {
    var match = /^https?:\/\/store\.steampowered\.com\/app\/(\d+)(?:\/|$)/i.exec(url);
    if (!match) throw new Error("Solte um link de jogo ou DLC de store.steampowered.com/app/.");
    var appid = match[1], http = new ActiveXObject("MSXML2.ServerXMLHTTP.6.0");
    http.setTimeouts(5000, 5000, 10000, 15000);
    http.open("GET", "https://store.steampowered.com/api/appdetails?appids=" + encodeURIComponent(appid), false);
    http.setRequestHeader("User-Agent", "SkyToolsPlugin/1.5.1-Millennium"); http.setRequestHeader("Accept", "application/json,*/*"); http.send();
    if (http.status < 200 || http.status >= 300) throw new Error("A Steam n\u00E3o retornou os dados deste link (HTTP " + http.status + ").");
    var json = (new Function("return (" + String(http.responseText || "{}") + ");"))();
    var item = json && json[appid], detail = item && item.success ? item.data : null;
    if (!detail) throw new Error("A Steam n\u00E3o retornou os dados deste link.");
    var type = String(detail.type || ""), name = String(detail.name || ("AppID " + appid));
    var parentId = detail.fullgame && detail.fullgame.appid ? String(detail.fullgame.appid) : "";
    var parentName = detail.fullgame && detail.fullgame.name ? String(detail.fullgame.name) : "";
    write('{"success":true,"data":{"appId":' + Number(appid) + ',"name":"' + esc(name) + '","type":"' + esc(type)
      + '","parentAppId":' + (parentId || "0") + ',"parentName":"' + esc(parentName) + '"}}');
  } catch (error) {
    write('{"success":false,"error":"' + esc(error && error.message ? error.message : String(error)) + '"}');
  }
})();
