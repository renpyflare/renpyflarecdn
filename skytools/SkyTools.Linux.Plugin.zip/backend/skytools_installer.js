// SkyTools one-shot installer for Windows Script Host.
// Runs with Windows Script Host and uses only files under the plugin folder plus Steam folders.
(function () {
  var fso = new ActiveXObject("Scripting.FileSystemObject");
  var shell = new ActiveXObject("WScript.Shell");

  function arg(index) {
    return WScript.Arguments.length > index ? String(WScript.Arguments.Item(index)) : "";
  }

  var dataRoot = arg(0);
  var steamPath = arg(1);
  var scriptDir = arg(2);
  var appId = arg(3);
  var gameName = arg(4);
  var preferred = arg(5) || "Automatic";
  var morrenusKey = arg(6);
  var resultPath = arg(7);
  var targetDlcId = arg(8);
  var targetDlcName = arg(9);
  var maxExpanded = 2 * 1024 * 1024 * 1024;
  var maxFiles = 32768;
  if (morrenusKey === "-") morrenusKey = "";

  function canonicalSourceId(id) {
    var value = String(id || "");
    var lower = value.toLowerCase();
    if (lower === "sushi" || lower === "ryzenapi" || lower === "greenhill") return "ryzen";
    return value;
  }

  preferred = canonicalSourceId(preferred);

  function combine(a, b) {
    if (!a) return b;
    return /[\\\/]$/.test(a) ? a + b : a + "\\" + b;
  }

  function ensureDir(path) {
    if (!path || fso.FolderExists(path)) return;
    var parent = fso.GetParentFolderName(path);
    if (parent && !fso.FolderExists(parent)) ensureDir(parent);
    if (!fso.FolderExists(path)) fso.CreateFolder(path);
  }

  function readTextWithCharset(path, charset) {
    if (!fso.FileExists(path)) return "";
    var stream = new ActiveXObject("ADODB.Stream");
    stream.Type = 2;
    stream.Charset = charset;
    stream.Open();
    stream.LoadFromFile(path);
    var text = stream.ReadText();
    stream.Close();
    return text;
  }

  function readText(path) {
    var charsets = ["utf-8", "windows-1252", "unicode"];
    for (var i = 0; i < charsets.length; i += 1) {
      try {
        return readTextWithCharset(path, charsets[i]);
      } catch (_) {
      }
    }
    var file = fso.OpenTextFile(path, 1, false);
    var text = file.ReadAll();
    file.Close();
    return text;
  }

  function writeText(path, text) {
    ensureDir(fso.GetParentFolderName(path));
    var stream = new ActiveXObject("ADODB.Stream");
    stream.Type = 2;
    stream.Charset = "utf-8";
    stream.Open();
    stream.WriteText(String(text || ""));
    stream.SaveToFile(path, 2);
    stream.Close();
  }

  function writeUtf8NoBom(path, text) {
    ensureDir(fso.GetParentFolderName(path));
    var textStream = new ActiveXObject("ADODB.Stream");
    textStream.Type = 2;
    textStream.Charset = "utf-8";
    textStream.Open();
    textStream.WriteText(String(text || ""));
    textStream.Position = 0;
    textStream.Type = 1;
    if (textStream.Size >= 3) {
      textStream.Position = 3;
    }

    var binaryStream = new ActiveXObject("ADODB.Stream");
    binaryStream.Type = 1;
    binaryStream.Open();
    textStream.CopyTo(binaryStream);
    binaryStream.SaveToFile(path, 2);
    binaryStream.Close();
    textStream.Close();
  }

  function writeBinary(path, bytes) {
    ensureDir(fso.GetParentFolderName(path));
    var stream = new ActiveXObject("ADODB.Stream");
    stream.Type = 1;
    stream.Open();
    stream.Write(bytes);
    stream.SaveToFile(path, 2);
    stream.Close();
  }

  function cleanText(value) {
    return String(value == null ? "" : value).replace(/\s+/g, " ").replace(/^\s+|\s+$/g, "");
  }

  function isPlaceholderGameName(value, id) {
    var name = cleanText(value);
    var app = String(id || "");
    if (!name) return true;
    if (app && name === app) return true;
    if (app && name.toLowerCase() === ("appid " + app).toLowerCase()) return true;
    return /^appid\s+\d+$/i.test(name);
  }

  function removeTree(path) {
    try {
      if (fso.FolderExists(path)) fso.DeleteFolder(path, true);
      if (fso.FileExists(path)) fso.DeleteFile(path, true);
    } catch (_) {}
  }

  function jsonEscape(value) {
    return String(value == null ? "" : value)
      .replace(/\\/g, "\\\\")
      .replace(/"/g, "\\\"")
      .replace(/\r/g, "\\r")
      .replace(/\n/g, "\\n")
      .replace(/\t/g, "\\t");
  }

  function toJson(value) {
    var type = typeof value;
    if (value === null || value === undefined) return "null";
    if (type === "number" || type === "boolean") return String(value);
    if (type === "string") return "\"" + jsonEscape(value) + "\"";
    if (Object.prototype.toString.call(value) === "[object Array]") {
      var items = [];
      for (var i = 0; i < value.length; i += 1) items.push(toJson(value[i]));
      return "[" + items.join(",") + "]";
    }
    var props = [];
    for (var key in value) {
      if (Object.prototype.hasOwnProperty.call(value, key)) {
        props.push("\"" + jsonEscape(key) + "\":" + toJson(value[key]));
      }
    }
    return "{" + props.join(",") + "}";
  }

  function readJson(path, fallback) {
    try {
      var text = readText(path);
      if (!text) return fallback;
      return (new Function("return (" + text + ");"))();
    } catch (_) {
      return fallback;
    }
  }

  function writeResult(payload) {
    writeText(resultPath, toJson(payload));
  }

  function isRawGitHubUrl(url) {
    return /^https?:\/\/raw\.githubusercontent\.com\//i.test(String(url || ""));
  }

  function normalizeDownloadUrl(url) {
    return String(url || "").replace(/(raw\.githubusercontent\.com\/[^\/]+\/[^\/]+)\/refs\/heads\/main\//i, "$1/main/");
  }

  function retryUrl(url, attempt) {
    if (attempt <= 1 || !isRawGitHubUrl(url)) return url;
    return url + (url.indexOf("?") >= 0 ? "&" : "?") + "skytools_retry=" + attempt + "_" + new Date().getTime();
  }

  function shouldRetryDownload(status, url) {
    if (status === 0 || status === 408 || status === 425 || status === 429) return true;
    if (status >= 500 && status <= 599) return true;
    if (status === 404 && isRawGitHubUrl(url)) return true;
    return false;
  }

  function downloadOnce(url, headers, target) {
    var psPath = combine(dataRoot, "skytools-download-" + appId + "-" + new Date().getTime() + ".ps1");
    var ps = [
      "$ErrorActionPreference = 'Stop'",
      "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12",
      "$source = '" + String(url || "").replace(/'/g, "''") + "'",
      "$destination = '" + String(target || "").replace(/'/g, "''") + "'",
      "if (Test-Path -LiteralPath $destination) { Remove-Item -LiteralPath $destination -Force -ErrorAction SilentlyContinue }",
      "Import-Module BitsTransfer -ErrorAction Stop",
      "curl.exe --tlsv1.2 -o $destination $source", 
      "if (!(Test-Path -LiteralPath $destination)) { throw 'BITS terminou sem criar o pacote.' }"
    ].join("\r\n");
    writeText(psPath, ps);
    var command = "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File " + quoteCmdArg(psPath);
    var exitCode = shell.Run(command, 0, true);
    removeTree(psPath);
    if (exitCode === 0 && fso.FileExists(target)) {
      return;
    }

    var http = new ActiveXObject("MSXML2.ServerXMLHTTP.6.0");
    try {
      http.setTimeouts(10000, 10000, 30000, 30000);
    } catch (_) {}
    http.open("GET", url, false);
    http.setRequestHeader("User-Agent", "SkyToolsPlugin/1.5.1-Millennium");
    http.setRequestHeader("Accept", "application/zip,application/octet-stream,*/*");
    if (headers) {
      for (var key in headers) {
        if (Object.prototype.hasOwnProperty.call(headers, key) && headers[key]) {
          http.setRequestHeader(key, headers[key]);
        }
      }
    }
    try {
      http.send();
    } catch (networkError) {
      var net = new Error("Falha de rede em " + url + ": " + (networkError && networkError.message ? networkError.message : String(networkError)));
      net.status = 0;
      throw net;
    }
    if (http.status < 200 || http.status >= 300) {
      var err = new Error("HTTP " + http.status + " em " + url);
      err.status = Number(http.status) || 0;
      throw err;
    }
    writeBinary(target, http.responseBody);
  }

  function download(url, headers, target) {
    var baseUrl = normalizeDownloadUrl(url);
    var attempts = isRawGitHubUrl(baseUrl) ? 4 : 3;
    var lastError = null;
    for (var attempt = 1; attempt <= attempts; attempt += 1) {
      var currentUrl = retryUrl(baseUrl, attempt);
      try {
        removeTree(target);
        downloadOnce(currentUrl, headers, target);
        return { attempts: attempt, url: currentUrl };
      } catch (error) {
        lastError = error;
        removeTree(target);
        if (attempt >= attempts || !shouldRetryDownload(Number(error.status) || 0, baseUrl)) {
          break;
        }
        WScript.Sleep(700 * attempt);
      }
    }
    var status = lastError && lastError.status ? ("HTTP " + lastError.status) : "falha";
    throw new Error(status + " em " + baseUrl + " ap\u00f3s " + attempts + " tentativa(s)");
  }

  function collectFiles(root, pattern, output) {
    if (!fso.FolderExists(root)) return output;
    var folder = fso.GetFolder(root);
    var files = new Enumerator(folder.Files);
    for (; !files.atEnd(); files.moveNext()) {
      var file = files.item();
      if (pattern.test(file.Name)) {
        if (output.length >= maxFiles) throw new Error("O pacote excede o limite de " + maxFiles + " arquivos.");
        output.push(file.Path);
      }
    }
    var folders = new Enumerator(folder.SubFolders);
    for (; !folders.atEnd(); folders.moveNext()) {
      collectFiles(folders.item().Path, pattern, output);
    }
    return output;
  }

  function quoteCmdArg(value) {
    return "\"" + String(value || "").replace(/"/g, "\"\"") + "\"";
  }

  function hasParentSegment(path) {
    var parts = String(path || "").split("/");
    for (var i = 0; i < parts.length; i++) if (parts[i] === "..") return true;
    return false;
  }

  function validateExtractedLimits(root) {
    var files = collectFiles(root, /./, []), total = 0;
    for (var i = 0; i < files.length; i++) {
      var size = Number(fso.GetFile(files[i]).Size);
      if (size < 0 || size > maxExpanded - total)
        throw new Error("O pacote excede o limite de 2 GB descompactados.");
      total += size;
    }
  }

  function tryExtractWithTar(zipPath, targetDir) {
    var listing;
    try { listing = shell.Exec("tar.exe -tf " + quoteCmdArg(zipPath)); }
    catch (_) { return false; }
    var output = listing.StdOut.ReadAll();
    if (listing.ExitCode !== 0) return false;
    var names = String(output || "").split(/\r?\n/), count = 0;
    for (var index = 0; index < names.length; index++) {
      var name = String(names[index] || "").replace(/\\/g, "/");
      if (!name) continue;
      if (name.charAt(0) === "/" || /^[A-Za-z]:/.test(name) || hasParentSegment(name))
        throw new Error("O pacote cont\u00E9m um caminho inseguro.");
      if (!/\/$/.test(name) && ++count > maxFiles)
        throw new Error("O pacote excede o limite de " + maxFiles + " arquivos.");
    }
    removeTree(targetDir);
    ensureDir(targetDir);
    var command = "tar.exe -xf " + quoteCmdArg(zipPath) + " -C " + quoteCmdArg(targetDir);
    if (shell.Run(command, 0, true) !== 0) return false;
    validateExtractedLimits(targetDir);
    var luaFiles = collectFiles(targetDir, /\.lua$/i, []);
    var manifestFiles = collectFiles(targetDir, /\.manifest$/i, []);
    return luaFiles.length > 0 || manifestFiles.length > 0;
  }

  function copyFolderFromZip(zipPath, targetDir) {
    ensureDir(targetDir);
    if (tryExtractWithTar(zipPath, targetDir)) return;

    var app = new ActiveXObject("Shell.Application");
    var source = app.NameSpace(zipPath);
    var target = app.NameSpace(targetDir);
    if (!source || !target) throw new Error("N\u00e3o foi poss\u00edvel abrir o pacote zip.");
    target.CopyHere(source.Items(), 4 | 16 | 512 | 1024);
    for (var i = 0; i < 120; i += 1) {
      WScript.Sleep(500);
      var luaFiles = collectFiles(targetDir, /\.lua$/i, []);
      var manifestFiles = collectFiles(targetDir, /\.manifest$/i, []);
      if (luaFiles.length > 0 || manifestFiles.length > 0) {
        validateExtractedLimits(targetDir);
        return;
      }
    }
    throw new Error("A extra\u00e7\u00e3o do pacote demorou demais ou n\u00e3o gerou arquivos v\u00e1lidos.");
  }

  function chooseScript(luaFiles) {
    var exact = String(appId) + ".lua";
    var numeric = null;
    for (var i = 0; i < luaFiles.length; i += 1) {
      var name = fso.GetFileName(luaFiles[i]);
      if (name.toLowerCase() === exact.toLowerCase()) return luaFiles[i];
      if (!numeric && /^\d+\.lua$/i.test(name)) numeric = luaFiles[i];
    }
    return numeric || luaFiles[0] || "";
  }

  function countDlcs(text, knownDlcIds) {
    var count = 0;
    var seen = {};
    text = String(text || "").replace(/--\[(=*)\[[\s\S]*?\]\1\]/g, "");
    text = text.replace(/--[^\r\n]*/g, "");
    var regex = /addappid\s*\(\s*(\d+)/ig;
    var match;
    while ((match = regex.exec(text)) !== null) {
      var id = String(match[1]);
      if (id !== String(appId) && (!knownDlcIds || knownDlcIds[id]) && !seen[id]) {
        seen[id] = true;
        count += 1;
      }
    }
    return count;
  }

  function replaceAll(text, token, value) {
    return String(text || "").split(token).join(value || "");
  }

  function pad2(value) {
    value = String(value);
    return value.length < 2 ? "0" + value : value;
  }

  function isoNow() {
    var date = new Date();
    return date.getFullYear() + "-"
      + pad2(date.getMonth() + 1) + "-"
      + pad2(date.getDate()) + "T"
      + pad2(date.getHours()) + ":"
      + pad2(date.getMinutes()) + ":"
      + pad2(date.getSeconds());
  }

  function sourceUrl(api) {
    var url = replaceAll(api.urlTemplate, "<appid>", appId);
    url = replaceAll(url, "<moapikey>", morrenusKey);
    url = replaceAll(url, "<apikey>", api.apiKey || "");
    if (api.useProxy && api.proxyUrlTemplate && String(api.proxyUrlTemplate).indexOf("<url>") >= 0) {
      url = replaceAll(api.proxyUrlTemplate, "<url>", encodeURIComponent(url));
    }
    return normalizeDownloadUrl(url);
  }

  function isDisabled(settings, id) {
    var disabled = settings && settings.DisabledApiIds ? settings.DisabledApiIds : [];
    if (Object.prototype.toString.call(disabled) !== "[object Array]") return false;
    for (var i = 0; i < disabled.length; i += 1) {
      if (String(disabled[i]).toLowerCase() === String(id).toLowerCase()) return true;
    }
    return false;
  }

  function nativeOverride(settings, id) {
    var overrides = settings && settings.NativeManifestApis ? settings.NativeManifestApis : {};
    var item = overrides && (overrides[id] || overrides[String(id).toLowerCase()]);
    return item || {};
  }

  function nativeSource(settings, id, name, urlTemplate, apiKey) {
    var override = nativeOverride(settings, id);
    if (isDisabled(settings, id) || override.enabled === false) return null;
    var source = {
      id: id,
      name: override.name || name,
      apiKey: override.apiKey || apiKey || "",
      urlTemplate: override.urlTemplate || urlTemplate,
      useProxy: override.useProxy === true,
      proxyUrlTemplate: override.proxyUrlTemplate || ""
    };
    if (!source.urlTemplate || String(source.urlTemplate).indexOf("<appid>") < 0) return null;
    if (id === "morrenus" && !source.apiKey) return null;
    return source;
  }

  function builtInSources(settings) {
    var sources = [];
    var greenhill = nativeSource(settings, "ryzen", "GreenHill", "https://api.ryzennetworking.duckdns.org/api/download/<appid>", "");
    var skyapi = nativeSource(settings, "skyapi", "SkyAPI", "https://raw.githubusercontent.com/skyflarefox/Skyapi/main/<appid>.zip", "");
    var morrenus = nativeSource(settings, "morrenus", "Morrenus", "https://hubcapmanifest.com/api/v1/manifest/<appid>?api_key=<moapikey>", morrenusKey);
    if (greenhill) {
      greenhill.name = "GreenHill";
      greenhill.urlTemplate = "https://api.ryzennetworking.duckdns.org/api/download/<appid>";
    }
    if (greenhill) sources.push(greenhill);
    if (skyapi) sources.push(skyapi);
    if (morrenus) sources.push(morrenus);
    return sources;
  }

  function orderSources(sources, settings) {
    var apiOrder = settings && settings.ApiOrder ? settings.ApiOrder : ["ryzen", "skyapi", "morrenus"];
    if (Object.prototype.toString.call(apiOrder) !== "[object Array]") apiOrder = ["ryzen", "skyapi", "morrenus"];
    apiOrder = apiOrder.slice(0);
    for (var g = apiOrder.length - 1; g >= 0; g -= 1) {
      if (canonicalSourceId(apiOrder[g]).toLowerCase() === "ryzen") apiOrder.splice(g, 1);
    }
    apiOrder.unshift("ryzen");
    var ranked = {};
    for (var r = 0; r < apiOrder.length; r += 1) {
      var id = canonicalSourceId(apiOrder[r]).toLowerCase();
      ranked[id] = r;
    }
    sources.sort(function (left, right) {
      var leftRank = ranked[String(left.id).toLowerCase()];
      var rightRank = ranked[String(right.id).toLowerCase()];
      if (leftRank == null) leftRank = 9999;
      if (rightRank == null) rightRank = 9999;
      if (leftRank !== rightRank) return leftRank - rightRank;
      return 0;
    });
    return sources;
  }

  function loadSources() {
    var settings = readJson(combine(dataRoot, "settings.json"), {});
    var custom = settings && settings.CustomManifestApis ? settings.CustomManifestApis : [];
    var sources = builtInSources(settings);
    if (Object.prototype.toString.call(custom) === "[object Array]") {
      for (var i = 0; i < custom.length; i += 1) {
        var item = custom[i] || {};
        if (item.enabled === false || !item.urlTemplate || String(item.urlTemplate).indexOf("<appid>") < 0) continue;
        sources.push({
          id: item.id || ("custom-" + i),
          name: item.name || ("API " + (i + 1)),
          urlTemplate: item.urlTemplate,
          apiKey: item.apiKey || "",
          useProxy: item.useProxy === true,
          proxyUrlTemplate: item.proxyUrlTemplate || "",
          headers: item.headers || null
        });
      }
    }
    sources = orderSources(sources, settings);
    if (preferred && preferred !== "Automatic") {
      var ordered = [];
      for (var p = 0; p < sources.length; p += 1) {
        if (String(sources[p].id).toLowerCase() === String(preferred).toLowerCase()) ordered.push(sources[p]);
      }
      for (var q = 0; q < sources.length; q += 1) {
        if (String(sources[q].id).toLowerCase() !== String(preferred).toLowerCase()) ordered.push(sources[q]);
      }
      sources = ordered;
    }
    if (settings && settings.AutomaticSourceFallback === false && sources.length > 1) {
      sources = [sources[0]];
    }
    return sources;
  }

  function readBinary(path) {
    var stream = new ActiveXObject("ADODB.Stream");
    stream.Type = 1; stream.Open(); stream.LoadFromFile(path);
    var bytes = new VBArray(stream.Read()).toArray(); stream.Close();
    return bytes;
  }

  function uint32(bytes, offset) {
    return (bytes[offset] | (bytes[offset + 1] << 8) | (bytes[offset + 2] << 16) | (bytes[offset + 3] << 24)) >>> 0;
  }

  function readVarint(bytes, state) {
    var value = 0, multiplier = 1, count = 0, next;
    do {
      if (state.offset >= bytes.length || count++ >= 10) throw new Error("metadados protobuf inv\u00E1lidos");
      next = bytes[state.offset++]; value += (next & 127) * multiplier; multiplier *= 128;
    } while (next & 128);
    return value;
  }
  function decimalTimes(text, multiplier) {
    var carry = 0, result = "";
    for (var i = text.length - 1; i >= 0; i -= 1) {
      var value = Number(text.charAt(i)) * multiplier + carry;
      result = String(value % 10) + result; carry = Math.floor(value / 10);
    }
    while (carry) { result = String(carry % 10) + result; carry = Math.floor(carry / 10); }
    return result.replace(/^0+(?=\d)/, "");
  }
  function decimalPlus(text, addition) {
    var carry = addition, index = text.length - 1, result = "";
    while (index >= 0 || carry) {
      var value = (index >= 0 ? Number(text.charAt(index--)) : 0) + carry;
      result = String(value % 10) + result; carry = Math.floor(value / 10);
    }
    return (index >= 0 ? text.substring(0, index + 1) : "") + result;
  }
  function readVarintDecimal(bytes, state) {
    var parts = [], count = 0, next;
    do {
      if (state.offset >= bytes.length || count++ >= 10) throw new Error("metadados protobuf inv\u00E1lidos");
      next = bytes[state.offset++]; parts.push(next & 127);
    } while (next & 128);
    var value = "0";
    for (var i = parts.length - 1; i >= 0; i -= 1) value = decimalPlus(decimalTimes(value, 128), parts[i]);
    return value;
  }

  function readMetadata(bytes) {
    var state = { offset: 0 }, result = {};
    while (state.offset < bytes.length) {
      var tag = readVarint(bytes, state), field = Math.floor(tag / 8), wire = tag % 8, value;
      if (wire === 0) value = field === 2 ? readVarintDecimal(bytes, state) : readVarint(bytes, state);
      else if (wire === 1) { state.offset += 8; continue; }
      else if (wire === 2) { state.offset += readVarint(bytes, state); continue; }
      else if (wire === 5) { state.offset += 4; continue; }
      else throw new Error("metadados protobuf inv\u00E1lidos");
      if (field === 1 || field === 2 || field === 4 || field === 8 || field === 9) result[field] = value;
      if (state.offset > bytes.length) throw new Error("metadados protobuf truncados");
    }
    return result;
  }

  function crc32(bytes, start, length) {
    var table = [], i, j, value;
    for (i = 0; i < 256; i++) { value = i; for (j = 0; j < 8; j++) value = (value & 1) ? (0xEDB88320 ^ (value >>> 1)) : (value >>> 1); table[i] = value; }
    var crc = 0xFFFFFFFF;
    for (i = start; i < start + length; i++) crc = table[(crc ^ bytes[i]) & 255] ^ (crc >>> 8);
    return (crc ^ 0xFFFFFFFF) >>> 0;
  }

  function validateManifest(path) {
    var name = fso.GetFileName(path);
    var identity = /^(\d+)_(\d+)\.manifest$/i.exec(name);
    if (!identity || identity[1] === "0" || identity[2] === "0") throw new Error(name + ": nome de manifest inv\u00E1lido.");
    var size = Number(fso.GetFile(path).Size);
    if (size <= 16 || size > 128 * 1024 * 1024) throw new Error(name + ": manifest vazio ou acima do limite.");
    var bytes = readBinary(path), offset = 0, payloadStart = -1, payloadLength = 0, metadata = null, signature = false, ended = false;
    while (offset + 4 <= bytes.length) {
      var magic = uint32(bytes, offset); offset += 4;
      if (magic === 0x32C415AB) { ended = offset === bytes.length && payloadStart >= 0 && metadata && signature; break; }
      if (offset + 4 > bytes.length) break;
      var length = uint32(bytes, offset); offset += 4;
      if (length > bytes.length - offset) break;
      if (magic === 0x71F617D0 && payloadStart < 0) { payloadStart = offset - 4; payloadLength = length + 4; }
      else if (magic === 0x1F4812BE && !metadata) metadata = readMetadata(bytes.slice(offset, offset + length));
      else if (magic === 0x1B81B817 && !signature) signature = true;
      else throw new Error(name + ": formato de manifest inv\u00E1lido.");
      offset += length;
    }
    if (!ended) throw new Error(name + ": manifest truncado ou sem marcador de t\u00E9rmino.");
    if (Number(metadata[1] || 0) !== Number(identity[1]) || String(metadata[2] || "") !== String(identity[2]))
      throw new Error(name + ": os IDs internos n\u00E3o correspondem ao nome do manifest.");
    var expectedCrc = Number(metadata[metadata[4] ? 8 : 9]);
    if (isNaN(expectedCrc) || crc32(bytes, payloadStart, payloadLength) !== (expectedCrc >>> 0))
      throw new Error(name + ": a verifica\u00E7\u00E3o de integridade (CRC) falhou.");
  }

  function httpJson(url) {
    var http = new ActiveXObject("MSXML2.ServerXMLHTTP.6.0");
    http.setTimeouts(5000, 5000, 12000, 18000);
    http.open("GET", url, false);
    http.setRequestHeader("User-Agent", "SkyToolsPlugin/1.5.1");
    http.setRequestHeader("Accept", "application/json,*/*");
    http.send();
    if (http.status < 200 || http.status >= 300) throw new Error("HTTP " + http.status);
    return (new Function("return (" + String(http.responseText || "{}") + ");"))();
  }

  function activeLuaEntries(text) {
    var entries = {}, lines = String(text || "").replace(/--\[(=*)\[[\s\S]*?\]\1\]/g, "").split(/\r\n|\n|\r/);
    for (var i = 0; i < lines.length; i++) {
      var match = lines[i].match(/^\s*addappid\s*\(\s*(\d+)/i);
      if (match) entries[match[1]] = lines[i];
    }
    return entries;
  }

  function steamDepotMap(scriptText) {
    var response;
    try { response = httpJson("https://api.steamcmd.net/v1/info/" + encodeURIComponent(appId)); }
    catch (_) { throw new Error("N\u00E3o foi poss\u00EDvel confirmar os depots do jogo na SteamCMD. Tente novamente."); }
    var app = response && response.data ? (response.data[String(appId)] || response.data[Number(appId)]) : null;
    if (!app || typeof app !== "object")
      throw new Error("N\u00E3o foi poss\u00EDvel confirmar os depots do jogo na SteamCMD. Tente novamente.");
    var map = { base: {}, optional: {}, shared: {}, dlcByDepot: {}, dlcIds: {}, all: {} }, depots = app.depots || {};
    var listedDlcs = String(app.extended && app.extended.listofdlc || "").split(",");
    for (var listedIndex = 0; listedIndex < listedDlcs.length; listedIndex++)
      if (/^\d+$/.test(String(listedDlcs[listedIndex]).replace(/\s/g, "")))
        map.dlcIds[String(listedDlcs[listedIndex]).replace(/\s/g, "")] = true;
    for (var id in depots) if (Object.prototype.hasOwnProperty.call(depots, id) && /^\d+$/.test(id)) {
      var depot = depots[id] || {}, config = depot.config || {};
      var shared = id === "228989" || id === "228990"
        || (depot.depotfromapp && String(depot.depotfromapp) !== String(appId))
        || depot.sharedinstall === true || String(depot.sharedinstall || "").toLowerCase() === "1"
        || String(depot.sharedinstall || "").toLowerCase() === "true";
      var dlcId = depot.dlcappid ? String(depot.dlcappid) : "", hasManifest = false;
      if (Object.prototype.hasOwnProperty.call(depot, "manifests") && depot.manifests && typeof depot.manifests === "object")
        for (var branch in depot.manifests) if (Object.prototype.hasOwnProperty.call(depot.manifests, branch)) { hasManifest = true; break; }
      var emptyDepot = Object.prototype.hasOwnProperty.call(depot, "manifests") && !hasManifest;
      var osList = String(config.oslist || "").toLowerCase().replace(/\s/g, "");
      var otherPlatform = osList && ("," + osList + ",").indexOf(",windows,") < 0;
      map.all[id] = true;
      if (dlcId) { map.dlcByDepot[id] = dlcId; map.dlcIds[dlcId] = true; }
      if (shared) map.shared[id] = true;
      else if (config.language || otherPlatform || emptyDepot) map.optional[id] = true;
      else if (!dlcId) map.base[id] = true;
    }

    // Some DLC depots are published only in the DLC app metadata, not in the parent app.
    if (targetDlcId) {
      map.dlcIds[String(targetDlcId)] = true;
      try {
        var targetResponse = httpJson("https://api.steamcmd.net/v1/info/" + encodeURIComponent(targetDlcId));
        var targetApp = targetResponse && targetResponse.data
          ? (targetResponse.data[String(targetDlcId)] || targetResponse.data[Number(targetDlcId)]) : null;
        var targetDepots = targetApp && targetApp.depots ? targetApp.depots : {};
        for (var targetDepotId in targetDepots) if (Object.prototype.hasOwnProperty.call(targetDepots, targetDepotId) && /^\d+$/.test(targetDepotId)) {
          var targetDepot = targetDepots[targetDepotId] || {}, targetConfig = targetDepot.config || {}, targetHasManifest = false;
          if (Object.prototype.hasOwnProperty.call(targetDepot, "manifests") && targetDepot.manifests && typeof targetDepot.manifests === "object")
            for (var targetBranch in targetDepot.manifests) if (Object.prototype.hasOwnProperty.call(targetDepot.manifests, targetBranch)) { targetHasManifest = true; break; }
          var targetOs = String(targetConfig.oslist || "").toLowerCase().replace(/\s/g, "");
          var targetShared = targetDepotId === "228989" || targetDepotId === "228990"
            || (targetDepot.depotfromapp && String(targetDepot.depotfromapp) !== String(appId))
            || targetDepot.sharedinstall === true || String(targetDepot.sharedinstall || "").toLowerCase() === "1"
            || String(targetDepot.sharedinstall || "").toLowerCase() === "true";
          map.all[targetDepotId] = true;
          map.dlcByDepot[targetDepotId] = String(targetDlcId);
          if (targetShared) map.shared[targetDepotId] = true;
          else if ((Object.prototype.hasOwnProperty.call(targetDepot, "manifests") && !targetHasManifest)
              || (targetOs && ("," + targetOs + ",").indexOf(",windows,") < 0)
              || targetConfig.language) map.optional[targetDepotId] = true;
        }
      } catch (_) {
        throw new Error("N\u00E3o foi poss\u00EDvel confirmar os depots da DLC na SteamCMD. Tente novamente.");
      }
    }

    var entries = activeLuaEntries(scriptText), inspected = 0;
    for (var candidate in entries) if (Object.prototype.hasOwnProperty.call(entries, candidate)
        && !map.all[candidate] && candidate !== String(appId)
        && /--.*\b(?:dlc|soundtrack|music)\b/i.test(entries[candidate]) && inspected++ < 64) {
      try {
        var store = httpJson("https://store.steampowered.com/api/appdetails?appids=" + encodeURIComponent(candidate));
        var detail = store && store[candidate] && store[candidate].success ? store[candidate].data : null;
        if (!detail || !detail.fullgame || String(detail.fullgame.appid) !== String(appId)) continue;
        var related = httpJson("https://api.steamcmd.net/v1/info/" + encodeURIComponent(candidate));
        var relatedApp = related && related.data ? (related.data[candidate] || related.data[Number(candidate)]) : null;
        var relatedDepots = relatedApp && relatedApp.depots ? relatedApp.depots : {};
        for (var relatedId in relatedDepots) if (Object.prototype.hasOwnProperty.call(relatedDepots, relatedId) && /^\d+$/.test(relatedId)) {
          var relatedDepot = relatedDepots[relatedId] || {}, relatedConfig = relatedDepot.config || {}, relatedHasManifest = false;
          if (Object.prototype.hasOwnProperty.call(relatedDepot, "manifests") && relatedDepot.manifests && typeof relatedDepot.manifests === "object")
            for (var relatedBranch in relatedDepot.manifests) if (Object.prototype.hasOwnProperty.call(relatedDepot.manifests, relatedBranch)) { relatedHasManifest = true; break; }
          var relatedOs = String(relatedConfig.oslist || "").toLowerCase().replace(/\s/g, "");
          map.all[relatedId] = true;
          map.dlcByDepot[relatedId] = candidate;
          map.dlcIds[candidate] = true;
          if ((Object.prototype.hasOwnProperty.call(relatedDepot, "manifests") && !relatedHasManifest)
              || (relatedOs && ("," + relatedOs + ",").indexOf(",windows,") < 0)
              || relatedConfig.language) map.optional[relatedId] = true;
        }
      } catch (_) {}
    }
    for (var canonical in map.dlcByDepot) if (Object.prototype.hasOwnProperty.call(map.dlcByDepot, canonical)
        && canonical === map.dlcByDepot[canonical] && !map.optional[canonical] && !map.shared[canonical]) {
      for (var alias in map.dlcByDepot) if (Object.prototype.hasOwnProperty.call(map.dlcByDepot, alias)
          && alias !== canonical && map.dlcByDepot[alias] === canonical) map.optional[alias] = true;
    }
    return map;
  }

  function removeBrokenLuaEntries(text, ids) {
    var lines = String(text || "").split(/\r\n|\n|\r/), kept = [];
    for (var i = 0; i < lines.length; i++) {
      var match = lines[i].match(/^\s*addappid\s*\(\s*(\d+)/i);
      if (!match || !ids[String(match[1])]) kept.push(lines[i]);
    }
    return kept.join("\r\n");
  }

  function ensureManifestLocks(text, identities) {
    var newline = String(text).indexOf("\r\n") >= 0 ? "\r\n" : "\n";
    var trailing = /[\r\n]$/.test(String(text)), lines = String(text || "").split(/\r\n|\n|\r/);
    for (var i = 0; i < identities.length; i++) {
      var wanted = identities[i], found = false;
      for (var lineIndex = 0; lineIndex < lines.length; lineIndex++) {
        var match = lines[lineIndex].match(/^(\s*)(--\s*)?(setmanifestid\s*\(\s*(\d+)\s*,\s*["']?(\d+)["']?\s*\))(\s*(?:--.*)?)$/i);
        if (!match || match[4] !== String(wanted.depotId) || match[5] !== String(wanted.manifestId)) continue;
        found = true;
        if (match[2]) lines[lineIndex] = match[1] + match[3] + match[6];
        break;
      }
      if (!found) lines.push("setManifestid(" + wanted.depotId + ",\"" + wanted.manifestId + "\")");
    }
    return lines.join(newline).replace(/[\r\n]+$/, "") + (trailing || lines.length ? newline : "");
  }

  function steamName(id) {
    try {
      var response = httpJson("https://store.steampowered.com/api/appdetails?appids=" + encodeURIComponent(id));
      var item = response ? response[String(id)] : null;
      return item && item.success && item.data && item.data.name ? String(item.data.name) : "AppID " + id;
    } catch (_) { return "AppID " + id; }
  }

  function filterPackage(scriptText, manifestFiles) {
    var depotMap = steamDepotMap(scriptText), valid = [], validByPair = {}, validByDepot = {}, broken = {}, seen = {};
    for (var manifestIndex = 0; manifestIndex < manifestFiles.length; manifestIndex++) {
      var fileName = String(fso.GetFileName(manifestFiles[manifestIndex])).toLowerCase();
      if (seen[fileName]) throw new Error("A sele\u00E7\u00E3o cont\u00E9m nomes de manifest repetidos.");
      seen[fileName] = true;
      var nameMatch = /^(\d+)_(\d+)\.manifest$/i.exec(fileName), depotId = nameMatch ? nameMatch[1] : "";
      if (depotId && depotId === String(appId)) { depotMap.base[depotId] = true; depotMap.all[depotId] = true; }
      if (!depotId || !depotMap.all[depotId])
        throw new Error("O pacote cont\u00E9m um depot que n\u00E3o pertence ao jogo: " + (depotId || fileName) + ".");
      try {
        validateManifest(manifestFiles[manifestIndex]);
        valid.push({ path: manifestFiles[manifestIndex], depotId: depotId, manifestId: nameMatch[2] });
        validByPair[depotId + "_" + nameMatch[2]] = true; validByDepot[depotId] = true;
      } catch (manifestError) { broken[depotId] = manifestError.message || String(manifestError); }
    }

    var entries = activeLuaEntries(scriptText), reference = /(?:^|[\r\n])\s*setmanifestid\s*\(\s*(\d+)\s*,\s*["']?(\d+)/ig, match;
    while ((match = reference.exec(scriptText))) {
      if (depotMap.all[match[1]] && !depotMap.shared[match[1]] && !depotMap.optional[match[1]]
          && !validByPair[match[1] + "_" + match[2]])
        broken[match[1]] = "o manifest referenciado pelo Lua est\u00E1 ausente ou inv\u00E1lido";
    }
    for (var baseId in depotMap.base) if (Object.prototype.hasOwnProperty.call(depotMap.base, baseId)
        && entries[baseId] && !validByDepot[baseId])
      broken[baseId] = broken[baseId] || "nenhum manifest v\u00E1lido foi fornecido para este depot";
    for (var dlcDepot in depotMap.dlcByDepot) if (Object.prototype.hasOwnProperty.call(depotMap.dlcByDepot, dlcDepot)) {
      var dlcId = depotMap.dlcByDepot[dlcDepot];
      if (entries[dlcId] && !depotMap.shared[dlcDepot] && !depotMap.optional[dlcDepot] && !validByDepot[dlcDepot])
        broken[dlcDepot] = broken[dlcDepot] || "nenhum manifest v\u00E1lido foi fornecido para este depot";
    }

    var primary = [], baseBroken = false, hasPrimary = false;
    for (baseId in depotMap.base) if (Object.prototype.hasOwnProperty.call(depotMap.base, baseId) && !depotMap.shared[baseId]) primary.push(baseId);
    if (!primary.length) for (var optionalId in depotMap.optional)
      if (Object.prototype.hasOwnProperty.call(depotMap.optional, optionalId) && !depotMap.shared[optionalId]) primary.push(optionalId);
    for (manifestIndex = 0; manifestIndex < primary.length; manifestIndex++) {
      if (depotMap.base[primary[manifestIndex]] && broken[primary[manifestIndex]]) baseBroken = true;
      if (validByDepot[primary[manifestIndex]]) hasPrimary = true;
    }
    if (baseBroken || !hasPrimary) {
      var details = [];
      for (manifestIndex = 0; manifestIndex < primary.length; manifestIndex++) if (broken[primary[manifestIndex]])
        details.push("Depot " + primary[manifestIndex] + ": " + broken[primary[manifestIndex]]);
      throw new Error("O manifest do jogo principal est\u00E1 ausente ou inv\u00E1lido." + (details.length ? " " + details.join("; ") : ""));
    }

    var removeIds = {}, removedDepots = {}, warnings = [];
    for (dlcDepot in depotMap.dlcByDepot) if (Object.prototype.hasOwnProperty.call(depotMap.dlcByDepot, dlcDepot) && broken[dlcDepot]) {
      dlcId = depotMap.dlcByDepot[dlcDepot];
      removeIds[dlcDepot] = true; removeIds[dlcId] = true; removedDepots[dlcDepot] = true;
      warnings.push("DLC removida do Lua: " + steamName(dlcId) + " (AppID " + dlcId + "). Motivo: depot " + dlcDepot + ": " + broken[dlcDepot] + ".");
    }
    if (warnings.length) scriptText = removeBrokenLuaEntries(scriptText, removeIds);
    var kept = [], identities = [];
    for (manifestIndex = 0; manifestIndex < valid.length; manifestIndex++)
      if (!removedDepots[valid[manifestIndex].depotId] && !broken[valid[manifestIndex].depotId]) {
        kept.push(valid[manifestIndex].path); identities.push(valid[manifestIndex]);
      }
    return { scriptText: ensureManifestLocks(scriptText, identities), manifests: kept, warnings: warnings, dlcIds: depotMap.dlcIds };
  }

  function requiredDlcDepots(map, dlcId) {
    var result = [];
    for (var depotId in map.dlcByDepot) if (Object.prototype.hasOwnProperty.call(map.dlcByDepot, depotId)
        && String(map.dlcByDepot[depotId]) === String(dlcId)
        && !map.shared[depotId] && !map.optional[depotId]) result.push(String(depotId));
    return result;
  }

  function hasDepotKey(line) {
    return /^[\s]*addappid\s*\(\s*\d+\s*,\s*(?:[01]\s*,\s*)?["'][0-9a-f]{64}["']\s*\)/i.test(String(line || ""));
  }

  function manifestReference(text, depotId) {
    var expression = new RegExp("(?:^|[\\r\\n])\\s*setmanifestid\\s*\\(\\s*" + depotId + "\\s*,\\s*[\\\"']?(\\d+)", "i");
    var match = expression.exec(String(text || ""));
    return match ? String(match[1]) : "";
  }

  function greenHillHasDepots(depots) {
    var response = httpJson("https://api.ryzennetworking.duckdns.org/api/dlcs/" + encodeURIComponent(appId));
    if (!response || String(response.appid) !== String(appId)
        || Object.prototype.toString.call(response.dlcs) !== "[object Array]") return false;
    var available = {};
    for (var i = 0; i < response.dlcs.length; i++) available[String(response.dlcs[i])] = true;
    for (i = 0; i < depots.length; i++) if (!available[String(depots[i])]) return false;
    return true;
  }

  function currentDlcManifests(currentText, depots) {
    var entries = activeLuaEntries(currentText), depotCache = combine(steamPath, "depotcache"), files = [];
    if (fso.FolderExists(depotCache)) files = collectFiles(depotCache, /\.manifest$/i, []);
    var identities = [];
    for (var d = 0; d < depots.length; d++) {
      var depotId = String(depots[d]);
      if (!entries[depotId] || !hasDepotKey(entries[depotId])) return null;
      var wantedManifest = manifestReference(currentText, depotId), found = null;
      for (var i = 0; i < files.length; i++) {
        var identity = /^(\d+)_(\d+)\.manifest$/i.exec(fso.GetFileName(files[i]));
        if (!identity || identity[1] !== depotId || (wantedManifest && identity[2] !== wantedManifest)) continue;
        try { validateManifest(files[i]); found = { path: files[i], depotId: depotId, manifestId: identity[2] }; break; }
        catch (_) {}
      }
      if (!found) return null;
      identities.push(found);
    }
    return identities;
  }

  function mergeDlcLua(current, source, dlcId, depots) {
    var sourceEntries = activeLuaEntries(source), ids = [String(dlcId)], output = [], comments = {}, wanted = {};
    for (var d = 0; d < depots.length; d++) ids.push(String(depots[d]));
    for (var w = 0; w < ids.length; w++) wanted[ids[w]] = true;
    var lines = String(current || "").split(/\r\n|\n|\r/);
    for (var i = 0; i < lines.length; i++) {
      var match = lines[i].match(/^\s*(?:--\s*)?addappid\s*\(\s*(\d+)/i);
      if (!match || !wanted[String(match[1])]) { output.push(lines[i]); continue; }
      var comment = lines[i].match(/--\s*(.+)$/);
      if (comment && !comments[String(match[1])]) comments[String(match[1])] = comment[1];
    }
    while (output.length && !output[output.length - 1]) output.pop();
    output.push("", "-- DolinTools");
    for (i = 0; i < ids.length; i++) {
      var id = ids[i], line = sourceEntries[id] || ("addappid(" + id + ")");
      if (comments[id]) line = String(line).replace(/\s+--.*$/, "") + " -- " + comments[id];
      else if (id === String(dlcId) && String(line).indexOf("--") < 0)
        line += " -- " + cleanText(targetDlcName || ("DLC " + dlcId));
      output.push(line);
    }
    return output.join("\r\n").replace(/[\r\n]+$/, "") + "\r\n";
  }

  function updateDlcRecord(scriptDestination, sourceName, installedFiles) {
    var recordsPath = combine(dataRoot, "manifest-installs.json"), records = readJson(recordsPath, []), record = null;
    if (Object.prototype.toString.call(records) !== "[object Array]") records = [];
    for (var i = 0; i < records.length; i++)
      if (String((records[i] || {}).AppId || (records[i] || {}).appId || "") === String(appId)) { record = records[i]; break; }
    if (!record) {
      record = { AppId: Number(appId), GameName: cleanText(gameName), InstalledAt: isoNow(), ManifestFiles: [] };
      records.push(record);
    }
    record.SourceName = sourceName;
    record.SourcePackage = sourceName;
    record.ScriptPath = scriptDestination;
    if (Object.prototype.toString.call(record.ManifestFiles) !== "[object Array]") record.ManifestFiles = [];
    for (var f = 0; f < installedFiles.length; f++) {
      var kept = [];
      for (var old = 0; old < record.ManifestFiles.length; old++)
        if (String((record.ManifestFiles[old] || {}).InstalledPath || "").toLowerCase()
            !== String(installedFiles[f].InstalledPath || "").toLowerCase()) kept.push(record.ManifestFiles[old]);
      record.ManifestFiles = kept;
      record.ManifestFiles.push(installedFiles[f]);
    }
    writeText(recordsPath, toJson(records));
  }

  function installDlcFromZip(zipPath, sourceName, depotMap, required) {
    var tempDir = combine(combine(dataRoot, "temp"), "dlc-" + appId + "-" + targetDlcId + "-" + new Date().getTime());
    var installedFiles = [], scriptDestination = combine(scriptDir, appId + ".lua"), previousScriptBackup = "";
    try {
      if (Number(fso.GetFile(zipPath).Size) > maxExpanded) throw new Error("O pacote excede o limite de 2 GB.");
      copyFolderFromZip(zipPath, tempDir);
      var manifestFiles = collectFiles(tempDir, /\.manifest$/i, []), luaFiles = collectFiles(tempDir, /\.lua$/i, []);
      var scriptSource = chooseScript(luaFiles);
      if (!scriptSource) throw new Error("Nenhum script .lua foi encontrado no pacote.");
      var sourceText = readText(scriptSource), entries = activeLuaEntries(sourceText);
      if (!entries[String(appId)]) throw new Error("O Lua do pacote n\u00E3o corresponde ao jogo solicitado.");
      var identities = [], selectedFiles = [];
      for (var r = 0; r < required.length; r++) {
        var depotId = String(required[r]);
        if (!entries[depotId] || !hasDepotKey(entries[depotId]))
          throw new Error("DLC " + targetDlcName + ": os dados de acesso do depot " + depotId + " n\u00E3o foram encontrados na API.");
        var wantedManifest = manifestReference(sourceText, depotId), found = null, lastError = "";
        for (var m = 0; m < manifestFiles.length; m++) {
          var identity = /^(\d+)_(\d+)\.manifest$/i.exec(fso.GetFileName(manifestFiles[m]));
          if (!identity || identity[1] !== depotId || (wantedManifest && identity[2] !== wantedManifest)) continue;
          try { validateManifest(manifestFiles[m]); found = { path: manifestFiles[m], depotId: depotId, manifestId: identity[2] }; break; }
          catch (manifestError) { lastError = manifestError.message || String(manifestError); }
        }
        if (!found) throw new Error("DLC " + targetDlcName + ": nenhum manifest v\u00E1lido foi encontrado para o depot "
          + depotId + (lastError ? " (" + lastError + ")" : "") + ".");
        identities.push(found); selectedFiles.push(found.path);
      }

      ensureDir(combine(steamPath, "depotcache")); ensureDir(scriptDir);
      var backupDir = combine(combine(combine(dataRoot, "manifest-backups"), appId), "dlc-" + new Date().getTime());
      for (var i = 0; i < selectedFiles.length; i++) {
        var destination = combine(combine(steamPath, "depotcache"), fso.GetFileName(selectedFiles[i])), previous = "";
        if (fso.FileExists(destination)) {
          previous = combine(combine(backupDir, "manifests"), fso.GetFileName(destination));
          ensureDir(fso.GetParentFolderName(previous)); fso.CopyFile(destination, previous, true);
        }
        fso.CopyFile(selectedFiles[i], destination, true);
        installedFiles.push({ InstalledPath: destination, PreviousBackup: previous });
      }
      var current = readText(scriptDestination);
      previousScriptBackup = combine(backupDir, fso.GetFileName(scriptDestination));
      ensureDir(fso.GetParentFolderName(previousScriptBackup)); fso.CopyFile(scriptDestination, previousScriptBackup, true);
      var updated = ensureManifestLocks(mergeDlcLua(current, sourceText, targetDlcId, required), identities);
      writeUtf8NoBom(scriptDestination, updated);
      updateDlcRecord(scriptDestination, sourceName, installedFiles);
      return { appId: Number(appId), gameName: gameName, scriptPath: scriptDestination,
        manifestCount: installedFiles.length, dlcCount: countDlcs(updated, depotMap.dlcIds), sourceName: sourceName,
        warnings: [], message: "DLC adicionada via " + sourceName + ": " + targetDlcName + "." };
    } catch (error) {
      for (var x = 0; x < installedFiles.length; x++) {
        if (installedFiles[x].PreviousBackup && fso.FileExists(installedFiles[x].PreviousBackup))
          fso.CopyFile(installedFiles[x].PreviousBackup, installedFiles[x].InstalledPath, true);
        else if (fso.FileExists(installedFiles[x].InstalledPath)) fso.DeleteFile(installedFiles[x].InstalledPath, true);
      }
      if (previousScriptBackup && fso.FileExists(previousScriptBackup)) fso.CopyFile(previousScriptBackup, scriptDestination, true);
      throw error;
    } finally { removeTree(tempDir); }
  }

  function installFromZip(zipPath, sourceName) {
    var tempDir = combine(combine(dataRoot, "temp"), "manifest-" + appId + "-" + new Date().getTime());
    var installedFiles = [];
    var scriptDestination = "";
    var previousScriptBackup = "";
    try {
      if (Number(fso.GetFile(zipPath).Size) > maxExpanded)
        throw new Error("O pacote excede o limite de 2 GB.");
      copyFolderFromZip(zipPath, tempDir);
      var manifestFiles = collectFiles(tempDir, /\.manifest$/i, []);
      var luaFiles = collectFiles(tempDir, /\.lua$/i, []);
      if (manifestFiles.length === 0) throw new Error("A API retornou apenas o arquivo Lua, sem nenhum arquivo .manifest.");
      var scriptSource = chooseScript(luaFiles);
      if (!scriptSource) throw new Error("Nenhum script .lua foi encontrado no pacote.");
      var scriptText = readText(scriptSource);
      if (!activeLuaEntries(scriptText)[String(appId)])
        throw new Error("O Lua do pacote n\u00E3o corresponde ao jogo solicitado.");
      var filtered = filterPackage(scriptText, manifestFiles), warnings = filtered.warnings;
      scriptText = filtered.scriptText;
      manifestFiles = filtered.manifests;

      var depotCache = combine(steamPath, "depotcache");
      ensureDir(depotCache);
      ensureDir(scriptDir);

      var backupDir = combine(combine(combine(dataRoot, "manifest-backups"), appId), String(new Date().getTime()));
      for (var i = 0; i < manifestFiles.length; i += 1) {
        var dest = combine(depotCache, fso.GetFileName(manifestFiles[i]));
        var previous = "";
        if (fso.FileExists(dest)) {
          previous = combine(combine(backupDir, "manifests"), fso.GetFileName(dest));
          ensureDir(fso.GetParentFolderName(previous));
          fso.CopyFile(dest, previous, true);
        }
        fso.CopyFile(manifestFiles[i], dest, true);
        installedFiles.push({ InstalledPath: dest, PreviousBackup: previous });
      }

      scriptDestination = combine(scriptDir, appId + ".lua");
      if (fso.FileExists(scriptDestination)) {
        previousScriptBackup = combine(backupDir, fso.GetFileName(scriptDestination));
        ensureDir(fso.GetParentFolderName(previousScriptBackup));
        fso.CopyFile(scriptDestination, previousScriptBackup, true);
      }
      var dlcCount = countDlcs(scriptText, filtered.dlcIds);
      writeUtf8NoBom(scriptDestination, scriptText);

      var recordsPath = combine(dataRoot, "manifest-installs.json");
      var records = readJson(recordsPath, []);
      if (Object.prototype.toString.call(records) !== "[object Array]") records = [];
      var kept = [];
      for (var r = 0; r < records.length; r += 1) {
        if (String((records[r] || {}).AppId || (records[r] || {}).appId || "") !== String(appId)) kept.push(records[r]);
      }
      var cleanGameName = isPlaceholderGameName(gameName, appId) ? "" : cleanText(gameName);
      kept.push({
        AppId: Number(appId),
        GameName: cleanGameName,
        SourceName: sourceName,
        InstalledAt: isoNow(),
        SourcePackage: sourceName,
        ScriptPath: scriptDestination,
        PreviousScriptBackup: previousScriptBackup,
        ManifestFiles: installedFiles
      });
      writeText(recordsPath, toJson(kept));

      var cachePath = combine(dataRoot, "skytools-app-name-cache.json");
      var cache = readJson(cachePath, {});
      if (!cache || typeof cache !== "object") cache = {};
      if (cleanGameName) {
        cache[String(appId)] = { AppId: Number(appId), Name: cleanGameName };
        writeText(cachePath, toJson(cache));
      }

      return {
        appId: Number(appId),
        gameName: cleanGameName || gameName,
        scriptPath: scriptDestination,
        manifestCount: manifestFiles.length,
        dlcCount: dlcCount,
        sourceName: sourceName,
        warnings: warnings,
        message: warnings.length ? ("Jogo adicionado via " + sourceName + ". " + warnings.join(" ")) : ""
      };
    } finally {
      removeTree(tempDir);
    }
  }

  try {
    if (!dataRoot || !steamPath || !scriptDir || !appId || !resultPath) {
      throw new Error("Par\u00e2metros insuficientes para instalar o jogo.");
    }
    ensureDir(dataRoot);
    if (!fso.FolderExists(steamPath)) throw new Error("Steam n\u00e3o encontrada: " + steamPath);

    var tempZip = combine(combine(dataRoot, "temp"), appId + "-" + new Date().getTime() + ".zip");
    var sources = loadSources();
    var errors = [];
    var result = null;
    var targetMap = null, targetRequired = [];
    if (targetDlcId) {
      var existingScript = combine(scriptDir, appId + ".lua");
      if (!fso.FileExists(existingScript)) throw new Error("O Lua do jogo base n\u00E3o foi encontrado.");
      var existingText = readText(existingScript);
      targetMap = steamDepotMap(existingText);
      targetRequired = requiredDlcDepots(targetMap, targetDlcId);
      if (!targetRequired.length) {
        var depotFreeText = activeLuaEntries(existingText)[String(targetDlcId)]
          ? existingText : mergeDlcLua(existingText, "", targetDlcId, []);
        if (depotFreeText !== existingText) writeUtf8NoBom(existingScript, depotFreeText);
        result = { appId: Number(appId), gameName: gameName, scriptPath: existingScript, manifestCount: 0,
          dlcCount: countDlcs(depotFreeText, targetMap.dlcIds), sourceName: "SteamCMD", warnings: [],
          message: "DLC sem depot adicionada: " + targetDlcName + "." };
      } else {
        var currentIdentities = currentDlcManifests(existingText, targetRequired);
        if (currentIdentities) {
          var currentUpdated = activeLuaEntries(existingText)[String(targetDlcId)]
            ? ensureManifestLocks(existingText, currentIdentities)
            : ensureManifestLocks(mergeDlcLua(existingText, existingText, targetDlcId, targetRequired), currentIdentities);
          if (currentUpdated !== existingText) writeUtf8NoBom(existingScript, currentUpdated);
          result = { appId: Number(appId), gameName: gameName, scriptPath: existingScript,
            manifestCount: currentIdentities.length, dlcCount: countDlcs(currentUpdated, targetMap.dlcIds),
            sourceName: "Instala\u00E7\u00E3o atual", warnings: [], message: "DLC j\u00E1 adicionada: " + targetDlcName + "." };
        }
      }
    }
    for (var s = 0; s < sources.length; s += 1) {
      if (result) break;
      try {
        if (targetDlcId && String(sources[s].id).toLowerCase() === "ryzen" && !greenHillHasDepots(targetRequired)) {
          errors.push(sources[s].name + ": a API n\u00E3o possui todos os manifests necess\u00E1rios para esta DLC.");
          continue;
        }
        download(sourceUrl(sources[s]), sources[s].headers, tempZip);
        result = targetDlcId
          ? installDlcFromZip(tempZip, sources[s].name, targetMap, targetRequired)
          : installFromZip(tempZip, sources[s].name);
        break;
      } catch (sourceError) {
        errors.push(sources[s].name + ": " + sourceError.message);
        removeTree(tempZip);
      }
    }
    if (!result) {
      throw new Error((targetDlcId
        ? "N\u00E3o foi encontrada uma DLC v\u00E1lida em nenhuma API."
        : "N\u00e3o foi encontrado um jogo v\u00e1lido em nenhuma API.") + (errors.length ? " " + errors.join(" | ") : ""));
    }
    removeTree(tempZip);
    writeResult({ success: true, data: result, error: "" });
  } catch (error) {
    writeResult({ success: false, error: error && error.message ? error.message : String(error) });
  }
})();
