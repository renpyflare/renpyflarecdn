// SkyTools script remover for Windows Script Host.
(function () {
  var fso = new ActiveXObject("Scripting.FileSystemObject");

  function arg(index) {
    return WScript.Arguments.length > index ? String(WScript.Arguments.Item(index)) : "";
  }

  function ensureDir(path) {
    if (!path || fso.FolderExists(path)) return;
    var parent = fso.GetParentFolderName(path);
    if (parent && !fso.FolderExists(parent)) ensureDir(parent);
    if (!fso.FolderExists(path)) fso.CreateFolder(path);
  }

  function writeText(path, text) {
    ensureDir(fso.GetParentFolderName(path));
    var stream = new ActiveXObject("ADODB.Stream");
    stream.Type = 2;
    stream.Charset = "utf-8";
    stream.Open();
    stream.WriteText(String(text || ""));
    stream.SaveToFile(path, 2);
    stream.Close();
  }

  function jsonEscape(value) {
    return String(value == null ? "" : value)
      .replace(/\\/g, "\\\\")
      .replace(/"/g, "\\\"")
      .replace(/\r/g, "\\r")
      .replace(/\n/g, "\\n")
      .replace(/\t/g, "\\t");
  }

  function stringArrayJson(values) {
    var parts = [];
    for (var i = 0; i < values.length; i += 1) {
      parts.push("\"" + jsonEscape(values[i]) + "\"");
    }
    return "[" + parts.join(",") + "]";
  }

  var resultPath = arg(0);
  var removed = [];
  var remaining = [];

  try {
    for (var i = 1; i < WScript.Arguments.length; i += 1) {
      var path = arg(i);
      if (!path) continue;
      if (fso.FileExists(path)) {
        try {
          fso.DeleteFile(path, true);
        } catch (_) {
        }
      }
      if (fso.FileExists(path)) {
        remaining.push(path);
      } else {
        removed.push(path);
      }
    }

    var success = remaining.length === 0;
    var error = success ? "" : "N\u00E3o foi poss\u00EDvel apagar: " + remaining.join(", ");
    writeText(resultPath, "{"
      + "\"success\":" + (success ? "true" : "false") + ","
      + "\"data\":{"
      + "\"removedPaths\":" + stringArrayJson(removed) + ","
      + "\"remainingPaths\":" + stringArrayJson(remaining)
      + "},"
      + "\"error\":\"" + jsonEscape(error) + "\""
      + "}");
  } catch (error) {
    writeText(resultPath, "{\"success\":false,\"error\":\""
      + jsonEscape(error && error.message ? error.message : String(error))
      + "\"}");
  }
})();
